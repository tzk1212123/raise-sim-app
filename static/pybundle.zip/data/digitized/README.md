# Digitised RAISE data

The raw RAISE data is unavailable: the paper's repository `AC-Formulations-SDL/RAISE` returns 404 as of 2026-11-04.
Everything in this folder is digitised from the published figures in arXiv 2510.06546 (main text + SI).
**This is a derivative of the authors' data, not raw measurements.**
Re-run the scripts in `tools/` to regenerate; the page images are produced from `references/raise/raise_arxiv_2510.06546.pdf`.

| File | Source | Method | Known limitations |
|---|---|---|---|
| `fig7a_single_surfactant.csv` | Fig. 7a, single surfactants 0–0.6 % w/v | colour mask per series at the 0.04 % columns, centroid of marker rows (`tools/digitize_fig7a.py`) | ~±0.5° pixel error; some Tween low-purity points hidden by overlap (blank) |
| `figS4a_contact_angle_grid.csv` | SI Fig. S4a contour (authors' interpolation of the campaign) | nearest colour band → band midpoint, ±1.5° quantisation (`tools/digitize_figS4a.py`) | inherits the authors' interpolation; legend region masked; SDS = 0.04 row is the plot edge |
| `fig8d_angle_vs_total.csv` | Fig. 8d, all campaign points | blob detection + clean-up rules (`tools/digitize_fig8d.py`) | 132 of 135 points recovered (overlaps); composition split unknown; colour bin approximate |
| `table1_optimal_formulations.csv` | Table 1 | column order recovered from the garbled PDF text, cross-checked against the red dots in Fig. S4 and the stars in Fig. 8d | — |
| `tableS2_water_on_pdms.csv` | SI Table S2 | transcribed | reproduces the reported SD of 0.805° |

## Findings from the digitisation that change the model

- **SDS 94 % alone plateaus at ≈ 60–62°, below SDS 99 % (≈ 72°).** The paper's text says the low-purity grade gave
  "substantially higher" angles, but Fig. 7a shows the opposite. SDS 94 % also reaches its plateau by about 0.08 %, versus about 0.28 % for SDS 99 %.
  This is consistent with salt and dodecanol impurities lowering both the CMC and γ.
- **Tween 20 alone is flat at ≈ 73–76°** across 0.04–0.6 %, as expected, since the whole range is above its CMC.
- So in the mixture, Tween **raises** the angle from the SDS 94 % plateau (~61°) towards its own (~75°).
  The 72° target is an iso-line in composition space. Fig. S4a and Fig. 8d both show that the angle depends mainly on the SDS : Tween ratio.
- The Table S2 noise splits into a within-level SD of 0.55° plus stage-level offsets spanning about 1.6° (levels A–E).
