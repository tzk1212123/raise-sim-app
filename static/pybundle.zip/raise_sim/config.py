"""Simulator configuration.

Values marked `to_confirm` in data/constants.yaml (stock concentrations, mixture
volume, timings) are assumptions here and must be replaced by measured local
values before hardware use.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Dict, Optional, Tuple


@dataclass
class SimConfig:
    # --- liquids (to_confirm: stock concentrations, mixture volume) ---
    stock_sds_wv: float = 2.0          # % w/v SDS 94 % stock
    stock_tween_wv: float = 4.0        # % w/v Tween 20 stock
    mixture_volume_uL: float = 200.0   # per formulation, mixed in a 360 uL well
    stock_volume_uL: Dict[str, float] = field(default_factory=lambda: {
        "sds": 15000.0, "tween": 15000.0, "water": 50000.0})
    well_capacity_uL: float = 360.0
    # --- pipettes (Opentrons GEN2) ---
    p20_range_uL: Tuple[float, float] = (1.0, 20.0)
    p300_range_uL: Tuple[float, float] = (20.0, 300.0)
    # --- protocol (RAISE paper / code) ---
    droplets: int = 3
    droplet_volume_uL: float = 3.0
    mix_cycles: int = 10
    mix_volume_uL: float = 100.0
    capture_wait_s: float = 10.0
    retry_extra_wait_s: float = 5.0
    max_retries: int = 1
    # --- deck: 2 stages x 5 levels x 9 positions = 90 droplets = 30 formulations per batch ---
    stages: int = 2
    stage_levels: int = 5
    positions_per_level: int = 9
    plate_wells: int = 96
    tips_p20: int = 96
    tips_p300: int = 96
    auto_reset: bool = True            # simulate the human batch reset when a consumable runs out
    # --- timing model, seconds (calibrate in pilot runs) ---
    t_tip_pick: float = 4.0
    t_tip_drop: float = 3.0
    t_transfer: float = 12.0
    t_mix_cycle: float = 3.0
    t_droplet_deposit: float = 8.0
    t_camera_pick: float = 15.0
    t_camera_return: float = 15.0
    t_camera_move: float = 5.0
    t_capture: float = 1.0
    t_manual_reset_s: float = 900.0    # human minutes per batch reset (logged separately)
    # --- measurement model ---
    seed: Optional[int] = None
    noise_scale: float = 1.0           # multiplies all noise terms (0 = noise-free)
    pipette_noise: bool = True
    detection_fail_p: float = 0.03
    retry_success_p: float = 0.7
    outlier_p: float = 0.02
    outlier_sd_deg: float = 8.0
    # --- task bounds enforced by the experiment API ---
    sds_bounds: Tuple[float, float] = (0.04, 0.60)
    tween_bounds: Tuple[float, float] = (0.04, 1.20)
    grid_step: Optional[float] = 0.04  # None = continuous inputs allowed
    data_dir: Optional[str] = None     # None = do not write run logs

    def to_dict(self) -> Dict:
        return asdict(self)
