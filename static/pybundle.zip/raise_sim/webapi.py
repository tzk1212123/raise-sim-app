"""The dashboard's /api/* endpoints for the in-browser build (GitHub Pages).

Runs inside Pyodide in a Web Worker (site/static/pyworker.js). There are no threads
there, so campaigns and races are computed to the end in one call and the page
replays them step by step (static/pyshim.js); a repeated study is advanced one
campaign per call so it can be stopped. LLM contestants are unavailable (no keys).
"""
from __future__ import annotations

import json
import random
import time
from pathlib import Path
from typing import Dict

from .benchmark import _job
from .study import WORLDS, Study, _flat
from .webcore import ApiError, Hub, contestant_ok, jsonable, lane_view, race_lane, race_meta, run_lane

ROOT = Path(__file__).resolve().parents[1]
hub = Hub()
study = Study(ROOT)
_jobs = []


def _benchmarks():
    out = []
    for d in sorted((ROOT / "reports").glob("benchmark*/summary.json")):
        try:
            out.append({"name": d.parent.name, "summary": json.loads(d.read_text(encoding="utf-8"))})
        except Exception:
            pass
    return out


def _campaign(b: Dict):
    hub.campaign = {"state": "idle"}
    p = hub.prepare_campaign(b.get("planner", "bo_angle"), int(b.get("budget", 15)), int(b.get("n_init", 3)),
                             int(b.get("seed", 0)), bool(b.get("fresh_rig", True)))
    hub.execute_campaign(p)
    return {"ok": True, "view": hub.campaign_view()}


def _race(b: Dict):
    planners = b.get("planners") or ["random", "ofat", "bo_ts", "bo_angle"]
    bad = [p for p in planners if not contestant_ok(p)]
    if bad:
        raise ApiError(400, f"unknown planners {bad}")
    budget, n_init, seed = int(b.get("budget", 15)), int(b.get("n_init", 3)), int(b.get("seed", 0))
    tt, meta = race_meta(hub, budget, n_init, seed)
    lanes = []
    for name in planners:
        lane = race_lane(hub, name, seed)
        run_lane(lane, budget, n_init, seed, tt)
        lanes.append(lane_view(lane))
    return {"ok": True, "view": {"meta": meta, "lanes": lanes, "running": False}}


def _study_start(b: Dict):
    global _jobs
    planners = b.get("planners") or ["random", "ofat", "bo_ts", "bo_angle"]
    bad = [p for p in planners if not contestant_ok(p)]
    if bad:
        raise ApiError(400, f"unknown planners {bad}")
    worlds = b.get("worlds", "physics")
    if worlds not in WORLDS:
        raise ApiError(400, "worlds must be physics or mixed")
    repeats, budget, n_init = int(b.get("repeats", 10)), int(b.get("budget", 15)), int(b.get("n_init", 3))
    if not (1 <= repeats <= 200):
        raise ApiError(400, "repeats must be 1-200")
    base = random.randint(1, 10 ** 6) if b.get("base_seed") is None else int(b["base_seed"])
    wl = WORLDS[worlds]
    _jobs = []
    for r in range(repeats):
        kind, idx = wl[r % len(wl)]
        for p in planners:
            _jobs.append((r, (p, kind, idx, budget, base + r, n_init, 5, {"noise_scale": 1.0}, {"log": None})))
    study.rows, study.raw = [], []
    study.state = {"state": "running", "planners": planners, "repeats": repeats, "budget": budget, "n_init": n_init,
                   "worlds": worlds, "base_seed": base, "total": len(_jobs), "done": 0, "errors": [],
                   "started": time.time(), "saved_to": None}
    return {"ok": True}


def _study_step(b: Dict):
    """Run the next campaign of the study; b = {"stop": bool}."""
    st = study.state
    if st.get("state") == "running":
        if b.get("stop") or not _jobs:
            st["state"] = "stopped" if _jobs else "done"
        else:
            r, args = _jobs.pop(0)
            try:
                m, trace = _job(args)
                study.rows.append(_flat(m, trace, r + 1))
                study.raw.append(m)
            except Exception as e:
                st["errors"].append(f"{args[0]} repeat {r + 1}: {type(e).__name__}: {e}")
            st["done"] += 1
            if not _jobs:
                st["state"] = "done"
        if st["state"] != "running":
            st["elapsed_s"] = round(time.time() - st["started"], 1)
    return study.view()


def _route(method: str, path: str, b: Dict):
    if method == "GET":
        if path == "/api/meta":
            m = hub.meta()
            m["browser_build"] = True
            return m
        if path == "/api/state":
            return hub.state()
        if path == "/api/truth":
            return hub.truth()
        if path == "/api/campaign":
            return hub.campaign_view()
        if path == "/api/benchmarks":
            return _benchmarks()
        if path == "/api/study":
            return study.view()
        if path == "/api/study/csv":
            return {"csv": study.csv()}
        if path == "/api/race":
            return {"meta": None, "lanes": [], "running": False}
    else:
        if path == "/api/run":
            return hub.run_one(float(b["sds"]), float(b["tween"]))
        if path == "/api/reset":
            hub.reset(b.get("surface", "physics"), int(b.get("seed", 0)), float(b.get("noise_scale", 1.0)))
            return {"ok": True}
        if path == "/api/manual_reset":
            hub.manual_reset()
            return {"ok": True}
        if path == "/api/campaign":
            return _campaign(b)
        if path == "/api/race":
            return _race(b)
        if path == "/api/study":
            return _study_start(b)
        if path == "/api/study/step":
            return _study_step(b)
        if path in ("/api/campaign/stop", "/api/race/stop", "/api/study/stop"):
            return {"ok": True}
    raise ApiError(404, f"no route {method} {path}")


def handle(method: str, path: str, body: str) -> str:
    """Entry point called from JavaScript; returns JSON {"status": int, "body": ...}."""
    try:
        b = json.loads(body) if body else {}
        return json.dumps({"status": 200, "body": jsonable(_route(method.upper(), path, b))})
    except ApiError as e:
        return json.dumps({"status": e.status, "body": {"detail": e.detail}})
    except Exception as e:
        return json.dumps({"status": 500, "body": {"detail": f"{type(e).__name__}: {e}"}})
