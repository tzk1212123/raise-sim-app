"""RAISE-style surfactant contact-angle simulator (SDS 94 % + Tween 20)."""
