"""Measurement model: true contact angle -> what camera + image analysis report.

Terms (all scaled by SimConfig.noise_scale):
  * stage-level offset: one fixed offset per stage level, drawn when a substrate
    is installed. Table S2 level means span ~1.6 deg (SD ~0.67 deg).
  * substrate ageing: slow drift per droplet already placed on that substrate.
  * replicate noise: within-level SD 0.55 deg for water (Table S2), inflated for
    surfactant solutions (Szymczyk et al. 2018 report 1-2 deg):
    sigma = 0.55 + 0.6 * (1 - exp(-total/0.1)).
  * outliers: with prob outlier_p a gross error (bad contour / tilt), N(0, 8 deg).
    The instrument cannot tell; the flag is kept only in ground-truth logs.
  * detection failure: no angle; up to max_retries retries with extra wait, each
    succeeding with prob retry_success_p (RAISE code behaviour).
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, Optional

import numpy as np

from .config import SimConfig

LEVEL_SD = 0.67
WITHIN_SD_WATER = 0.55
AGE_DRIFT_PER_DROPLET = -0.01


@dataclass
class DropletReading:
    angle: Optional[float]
    failed: bool
    outlier: bool
    retries: int
    stage: int
    level: int
    position: int

    def public(self) -> Dict:
        return {"angle_deg": None if self.angle is None else round(self.angle, 2),
                "status": "failed" if self.failed else "ok", "retries": self.retries,
                "stage": self.stage, "level": self.level, "position": self.position}


class MeasurementModel:
    def __init__(self, cfg: SimConfig, rng: np.random.Generator):
        self.cfg, self.rng = cfg, rng
        self.level_offsets: Dict[int, np.ndarray] = {}
        self.droplets_on_stage: Dict[int, int] = {}
        for s in range(cfg.stages):
            self.install_substrate(s)

    def install_substrate(self, stage: int) -> None:
        self.level_offsets[stage] = self.rng.normal(0, LEVEL_SD, self.cfg.stage_levels) * self.cfg.noise_scale
        self.droplets_on_stage[stage] = 0

    def sigma(self, sds_wv: float, tween_wv: float) -> float:
        s = 1 - math.exp(-(sds_wv + tween_wv) / 0.1)
        return (WITHIN_SD_WATER + 0.6 * s) * self.cfg.noise_scale

    def place_droplet(self, stage: int) -> int:
        """Register a droplet on a substrate; returns its age index (for drift)."""
        age = self.droplets_on_stage[stage]
        self.droplets_on_stage[stage] += 1
        return age

    def apparent_angle(self, theta_true: float, sds_wv: float, tween_wv: float,
                       stage: int, level: int, age: int) -> float:
        """The physical angle the camera sees on this spot (offsets + drift + noise)."""
        cfg = self.cfg
        return float(theta_true + self.level_offsets[stage][level]
                     + AGE_DRIFT_PER_DROPLET * age * cfg.noise_scale
                     + self.rng.normal(0, self.sigma(sds_wv, tween_wv)))

    def analyse(self, apparent: float, attempt: int):
        """Image analysis of one capture -> (angle | None, outlier_flag)."""
        cfg, rng = self.cfg, self.rng
        if cfg.noise_scale > 0:
            p_fail = cfg.detection_fail_p if attempt == 0 else 1 - cfg.retry_success_p
            if rng.random() < p_fail:
                return None, False
            if rng.random() < cfg.outlier_p:
                return float(apparent + rng.normal(0, cfg.outlier_sd_deg)), True
        return float(apparent), False
