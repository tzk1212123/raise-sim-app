"""Command-line entry points.

    python -m raise_sim.cli run 0.08 0.20               # one formulation, prints the record
    python -m raise_sim.cli devices                      # device manifests
    python -m raise_sim.cli campaign --planner bo_angle --budget 30 --seed 0
    python -m raise_sim.cli truth                        # noise-free map + optimum of the surface
"""
from __future__ import annotations

import argparse
import json

from .experiment import create_experiment
from .planners import make_planner, run_campaign
from .task import T1


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--surface", default="physics", choices=["physics", "family", "gp"])
    ap.add_argument("--surface-index", type=int, default=1)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--data-dir", default=None)
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run"); r.add_argument("sds", type=float); r.add_argument("tween", type=float)
    sub.add_parser("devices")
    sub.add_parser("truth")
    c = sub.add_parser("campaign")
    c.add_argument("--planner", default="bo_angle")
    c.add_argument("--budget", type=int, default=30)
    c.add_argument("--n-init", type=int, default=3)
    a = ap.parse_args(argv)
    exp = create_experiment(a.surface, a.surface_index, seed=a.seed, data_dir=a.data_dir)
    if a.cmd == "run":
        print(json.dumps(exp.run(a.sds, a.tween), indent=2))
    elif a.cmd == "devices":
        print(json.dumps(exp.registry.manifests(), indent=2))
    elif a.cmd == "truth":
        from .benchmark import truth_table
        tt = truth_table(exp.lab.surface, T1)
        print(json.dumps({"best_in_window": tt["best_in_window"], "D_star": round(tt["D_star"], 4),
                          "n_good_points": len(tt["good"]),
                          "good_points": sorted(tt["good"])}, indent=2))
    elif a.cmd == "campaign":
        exp.listeners.append(print)
        p = make_planner(a.planner, T1, seed=a.seed)
        res = run_campaign(exp, p, a.budget, n_init=a.n_init, seed=a.seed)
        print(json.dumps({"recommendation": res["recommendation"], "notes": res["notes"],
                          "status": exp.status()}, indent=2, default=str))


if __name__ == "__main__":
    main()
