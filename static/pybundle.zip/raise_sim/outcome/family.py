"""A family of plausible ground-truth surfaces.

The true RAISE surface is unknown, so benchmark claims must hold across a set of
surfaces consistent with the digitised data. Draws come from the Laplace
approximation of model A's fit, with the covariance inflated (default x4 in
variance) because neighbouring S4a cells are interpolated by the authors and
therefore strongly correlated, which makes the naive covariance overconfident.
Draws whose fit RMSE to the data degrades by more than `max_rmse_increase`
degrees are rejected.
"""
from __future__ import annotations

import json
from dataclasses import replace
from typing import List

import numpy as np

from . import data
from .fit import FREE, datasets
from .physics import PhysicsModel, PhysicsParams


def _load():
    return json.loads(open(data.ROOT / "data" / "model" / "physics_v1.json").read())


def _to_params(z, base: PhysicsParams) -> PhysicsParams:
    kw = {}
    for (k, (_, lo, hi, lg)), v in zip(FREE.items(), z):
        lo_t, hi_t = (np.log(lo), np.log(hi)) if lg else (lo, hi)
        v = float(np.clip(v, lo_t, hi_t))
        kw[k] = float(np.exp(v)) if lg else v
    return replace(base, **kw)


def _rmse(m: PhysicsModel, D) -> float:
    e = np.concatenate([[m(s, t) - th for s, t, th in arr] for arr in D.values()])
    return float(np.sqrt((e ** 2).mean()))


def sample_family(n: int = 20, seed: int = 0, inflate: float = 4.0,
                  max_rmse_increase: float = 0.5) -> List[PhysicsModel]:
    fit = _load()
    base = PhysicsParams(**fit["params"])
    z0, cov = np.array(fit["z_opt"]), np.array(fit["cov_z"]) * inflate
    D = datasets()
    ref = _rmse(PhysicsModel(base), D)
    rng = np.random.default_rng(seed)
    out = [PhysicsModel(base)]
    tries = 0
    while len(out) < n and tries < 50 * n:
        tries += 1
        z = rng.multivariate_normal(z0, cov)
        m = PhysicsModel(_to_params(z, base))
        if _rmse(m, D) <= ref + max_rmse_increase:
            m.name = f"physics_v1_draw{len(out)}"
            out.append(m)
    return out
