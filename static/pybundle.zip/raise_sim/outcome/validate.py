"""Validation checks for outcome model A (writes reports/outcome_validation.json + figures).

    python -m raise_sim.outcome.validate
"""
from __future__ import annotations

import json
from dataclasses import replace

import numpy as np
from scipy.optimize import least_squares

from . import data
from .physics import PhysicsModel, PhysicsParams
from ..task import T1


def load(path=None) -> PhysicsModel:
    path = path or data.ROOT / "data" / "model" / "physics_v1.json"
    return PhysicsModel(PhysicsParams(**json.loads(open(path).read())["params"]))


def check_sds99_structure():
    """Fit the SAME single-component form to the independent SDS 99 % curve with purity 1.
    If the structure is right, the fitted CMC should land near the literature 8.2 mM."""
    d = data.fig7a("SDS99"); d = d[d[:, 0] > 0]

    def res(z):
        p = replace(PhysicsParams(), sds_purity=1.0, cmc_s_mM=float(np.exp(z[0])),
                    pi_plat_s=float(z[1]), kappa_s=float(np.exp(z[2])))
        m = PhysicsModel(p)
        return np.array([m(c, 0.0) for c in d[:, 0]]) - d[:, 1]

    r = least_squares(res, [np.log(8.0), 35.0, np.log(5.0)],
                      bounds=([np.log(0.5), 20, np.log(0.1)], [np.log(30), 50, np.log(1000)]))
    return {"fitted_cmc_mM": round(float(np.exp(r.x[0])), 2), "literature_cmc_mM": 8.2,
            "plateau_pi": round(float(r.x[1]), 2), "rmse_deg": round(float(np.sqrt((r.fun ** 2).mean())), 2)}


def check_fig8d_coverage(m: PhysicsModel, tol=2.0, include_tween_zero=True):
    """Each campaign point (total, angle) should be reachable by SOME grid composition with
    that total. Fig 8d is a hold-out: it was not used in the fit.
    include_tween_zero: the low-angle, low-total points match SDS 94 % alone (Fig 7a)
    point for point, which suggests the campaign also sampled Tween = 0."""
    pts = data.fig8d()
    grid = T1.grid()
    if include_tween_zero:
        grid = grid + [(round(0.04 * i, 2), 0.0) for i in range(1, 16)]
    by_total = {}
    for s, t in grid:
        by_total.setdefault(round(s + t, 2), []).append(m(s, t))
    miss = []
    for tot, th in pts:
        key = min(by_total, key=lambda k: abs(k - tot))
        lo, hi = min(by_total[key]), max(by_total[key])
        if not (lo - tol <= th <= hi + tol):
            miss.append([round(tot, 2), round(th, 1), round(lo, 1), round(hi, 1)])
    return {"n_points": int(len(pts)), "n_outside_model_range_pm2deg": len(miss), "outside": miss}


def check_table1(m: PhysicsModel):
    rows = []
    for s, t, th in data.table1():
        p = m(s, t)
        rows.append({"sds": s, "tween": t, "observed": th, "model": round(p, 2),
                     "within_72pm2": bool(70 <= p <= 74)})
    return rows


def check_optimum(m: PhysicsModel):
    g = T1.grid()
    scored = sorted(((T1.desirability(m(s, t), s, t), s, t, m(s, t)) for s, t in g), reverse=True)
    opt = [x for x in scored if T1.is_optimal(x[3], x[1], x[2])]
    return {"top5": [[round(d, 3), s, t, round(th, 2)] for d, s, t, th in scored[:5]],
            "n_optimal_noise_free": len(opt),
            "best_optimal": [round(opt[0][0], 3), opt[0][1], opt[0][2], round(opt[0][3], 2)] if opt else None}


def main():
    m = load()
    rep = {
        "sds99_structure_check": check_sds99_structure(),
        "fig8d_holdout_coverage_with_tween0": check_fig8d_coverage(m, include_tween_zero=True),
        "fig8d_holdout_coverage_task_domain_only": {k: v for k, v in check_fig8d_coverage(m, include_tween_zero=False).items() if k != "outside"},
        "table1": check_table1(m),
        "task_optimum_noise_free": check_optimum(m),
    }
    out = data.ROOT / "reports" / "outcome_validation.json"
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(rep, indent=2, default=float))
    print(json.dumps(rep, indent=2, default=float))


if __name__ == "__main__":
    main()
