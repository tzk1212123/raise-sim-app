"""Model B: Gaussian-process emulator fitted directly to the digitised surface.

Inputs are (SDS, Tween) in % w/v, mapped to log space because the response
changes fastest at low concentration. Per-point noise: S4a cells sigma 2.0 deg,
Table 1 sigma 0.8 deg. Use it as an independent "world" to check that planner
rankings do not hinge on model A's functional form.
"""
from __future__ import annotations

import pickle

import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel, Matern

from . import data


def _x(s, t):
    return np.c_[np.log(np.atleast_1d(s)), np.log(np.atleast_1d(t))]


class GPEmulator:
    name = "gp_emulator_v1"

    def __init__(self, seed: int = 0):
        S, T = data.figS4a(), data.table1()
        X = np.vstack([_x(S[:, 0], S[:, 1]), _x(T[:, 0], T[:, 1])])
        y = np.r_[S[:, 2], T[:, 2]]
        alpha = np.r_[np.full(len(S), 2.0 ** 2), np.full(len(T), 0.8 ** 2)]
        k = ConstantKernel(20.0, (1.0, 400.0)) * Matern([0.7, 0.7], (0.05, 10.0), nu=2.5)
        self.gp = GaussianProcessRegressor(k, alpha=alpha, normalize_y=True, n_restarts_optimizer=3,
                                           random_state=seed).fit(X, y)

    def contact_angle(self, sds: float, tween: float) -> float:
        return float(self.gp.predict(_x(sds, tween))[0])

    __call__ = contact_angle

    def predict(self, sds, tween, return_std=False):
        return self.gp.predict(_x(sds, tween), return_std=return_std)

    def sample_surface(self, points, seed: int):
        """One posterior draw of the latent surface on `points` [(s, t), ...]."""
        P = np.array(points)
        return self.gp.sample_y(_x(P[:, 0], P[:, 1]), random_state=seed).ravel()
