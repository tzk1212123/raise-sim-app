"""Physics-structured outcome model (model A).

Chain:  composition (% w/v) -> molar -> monomer concentrations (Rubingh mixed
micelles) -> competitive Langmuir coverage -> effective surface pressure Pi ->
effective wetting tension gamma = gamma_w - Pi -> contact angle via the
calibrated adhesion-tension line  gamma*cos(theta) = a*gamma + b.

"Effective" matters: the parameters absorb solid-liquid adsorption and the
SDS 94 % impurities (NaCl, dodecanol), so gamma here is a wetting tension, not
a measured liquid-air surface tension. Literature values are priors, not facts.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, asdict, field
from typing import Dict

import numpy as np
from scipy.optimize import brentq

GAMMA_WATER = 72.8  # mN/m, 20-25 C
MW_SDS = 288.38
MW_TWEEN = 1228.0


@dataclass
class PhysicsParams:
    # adhesion-tension line, from anchors (water 101.5 deg; SDS 99 % plateau 72 deg at 38 mN/m)
    a: float = -0.7546
    b: float = 40.42
    # SDS 94 % pseudo-component (active fraction 0.94)
    sds_purity: float = 0.94
    cmc_s_mM: float = 2.6          # effective, lowered by salt/impurities
    pi_plat_s: float = 40.0        # effective surface pressure at plateau, mN/m
    kappa_s: float = 20.0          # CMC / Langmuir constant (sharpness of approach)
    # Tween 20
    cmc_t_mM: float = 0.06
    pi_plat_t: float = 33.2
    kappa_t: float = 20.0
    # interactions
    beta_m: float = -2.1           # mixed-micelle (Rubingh)
    beta_s: float = 0.0            # monolayer non-ideality term in Pi, mN/m

    def to_dict(self) -> Dict[str, float]:
        return asdict(self)


class PhysicsModel:
    name = "physics_v1"

    def __init__(self, params: PhysicsParams | None = None):
        self.p = params or PhysicsParams()

    # -- concentrations -------------------------------------------------
    def molar(self, sds_wv: float, tween_wv: float):
        cs = sds_wv * 10.0 / MW_SDS * 1000.0 * self.p.sds_purity  # mM active SDS
        ct = tween_wv * 10.0 / MW_TWEEN * 1000.0                   # mM
        return cs, ct

    def monomers(self, cs: float, ct: float):
        """Monomer concentrations (mM) from Rubingh regular-solution mixed micelles."""
        p = self.p
        if cs <= 0 and ct <= 0:
            return 0.0, 0.0
        if ct <= 0:
            return min(cs, p.cmc_s_mM), 0.0
        if cs <= 0:
            return 0.0, min(ct, p.cmc_t_mM)

        def mono(X):
            ms = X * math.exp(p.beta_m * (1 - X) ** 2) * p.cmc_s_mM
            mt = (1 - X) * math.exp(p.beta_m * X ** 2) * p.cmc_t_mM
            return ms, mt

        def g(X):
            ms, mt = mono(X)
            return (cs - ms) * (1 - X) - (ct - mt) * X

        lo, hi = 1e-9, 1 - 1e-9
        glo, ghi = g(lo), g(hi)
        if glo * ghi > 0:
            return cs, ct  # no micellar solution -> below mixed CMC
        X = brentq(g, lo, hi, xtol=1e-12)
        ms, mt = mono(X)
        if ms > cs or mt > ct:  # micelle amount would be negative
            return cs, ct
        return ms, mt

    # -- interface -------------------------------------------------------
    def surface_pressure(self, sds_wv: float, tween_wv: float) -> float:
        p = self.p
        cs, ct = self.molar(sds_wv, tween_wv)
        ms, mt = self.monomers(cs, ct)
        us, ut = ms / p.cmc_s_mM, mt / p.cmc_t_mM
        ks, kt = p.kappa_s, p.kappa_t
        denom = 1 + ks * us + kt * ut
        th_s, th_t = ks * us / denom, kt * ut / denom
        pinf_s = p.pi_plat_s * (1 + ks) / ks
        pinf_t = p.pi_plat_t * (1 + kt) / kt
        return pinf_s * th_s + pinf_t * th_t + p.beta_s * th_s * th_t

    def wetting_tension(self, sds_wv: float, tween_wv: float) -> float:
        return max(GAMMA_WATER - self.surface_pressure(sds_wv, tween_wv), 15.0)

    def contact_angle(self, sds_wv: float, tween_wv: float) -> float:
        g = self.wetting_tension(sds_wv, tween_wv)
        c = self.p.a + self.p.b / g
        return math.degrees(math.acos(max(-1.0, min(1.0, c))))

    __call__ = contact_angle

    def grid(self, sds_vals, tween_vals) -> np.ndarray:
        return np.array([[self.contact_angle(s, t) for t in tween_vals] for s in sds_vals])
