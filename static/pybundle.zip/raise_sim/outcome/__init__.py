"""Ground-truth outcome models: formulation -> true static contact angle.

Planners never import this package; they only see measurements returned by the
simulated instrument.
"""
from .physics import PhysicsParams, PhysicsModel

__all__ = ["PhysicsParams", "PhysicsModel"]
