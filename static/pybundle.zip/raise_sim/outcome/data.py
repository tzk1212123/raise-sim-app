"""Loaders for the digitised RAISE data (see data/digitized/README.md)."""
from __future__ import annotations

import csv
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
DIG = ROOT / "data" / "digitized"


def _rows(name):
    with open(DIG / name, newline="") as f:
        return list(csv.DictReader(f))


def fig7a(series: str):
    r = [x for x in _rows("fig7a_single_surfactant.csv") if x["series"] == series and x["contact_angle_deg"]]
    return np.array([[float(x["conc_wv_pct"]), float(x["contact_angle_deg"])] for x in r])


def figS4a():
    """Returns array of (sds, tween, angle) for non-masked grid cells."""
    r = [x for x in _rows("figS4a_contact_angle_grid.csv") if x["contact_angle_deg"]]
    return np.array([[float(x["sds_wv_pct"]), float(x["tween_wv_pct"]), float(x["contact_angle_deg"])] for x in r])


def table1():
    r = _rows("table1_optimal_formulations.csv")
    return np.array([[float(x["sds94_wv_pct"]), float(x["tween20_wv_pct"]), float(x["contact_angle_deg"])] for x in r])


def fig8d(snap: float | None = 0.04):
    """(total, angle). Totals snapped to the 0.04 % grid by default (digitising error ~0.003 %)."""
    r = _rows("fig8d_angle_vs_total.csv")
    a = np.array([[float(x["total_wv_pct"]), float(x["contact_angle_deg"])] for x in r])
    if snap:
        a[:, 0] = np.round(a[:, 0] / snap) * snap
    return a
