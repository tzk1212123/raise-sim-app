"""Fit model A to the digitised data.

    python -m raise_sim.outcome.fit            # writes data/model/physics_v1.json

Weights (1/sigma): Table 1 exact values sigma=0.8 (replicate SD); Fig. 7a points
sigma=1.0 (replicate + digitising); Fig. S4a cells sigma=2.0 (3-deg bands plus the
authors' interpolation, and cells are spatially correlated so they are down-weighted).
"""
from __future__ import annotations

import json
from dataclasses import replace

import numpy as np
from scipy.optimize import least_squares

from . import data
from .physics import PhysicsModel, PhysicsParams, GAMMA_WATER

FREE = {  # name: (init, lo, hi, log-scale)
    "cmc_s_mM": (2.6, 0.5, 9.0, True),
    "pi_plat_s": (40.0, 25.0, 50.0, False),
    "kappa_s": (20.0, 0.5, 500.0, True),
    "cmc_t_mM": (0.03, 0.005, 0.1, True),
    "pi_plat_t": (33.0, 20.0, 45.0, False),
    "kappa_t": (20.0, 0.5, 500.0, True),
    "beta_m": (-2.0, -8.0, 2.0, False),
    "beta_s": (-30.0, -60.0, 60.0, False),
}
SIG = {"table1": 0.8, "fig7a": 1.0, "s4a": 2.0}
# Weak literature priors (residual units = prior SDs). They only bite where the
# digitised data cannot identify a parameter.
PRIORS = {
    "cmc_t_mM": ("log", np.log(0.02), 1.0),   # 0.007-0.06 mM literature span
    "beta_m": ("lin", -2.0, 2.0),             # anionic-nonionic: synergistic (negative)
    "beta_s": ("lin", 0.0, 20.0),
}
USE_PRIORS = True


def _unpack(z):
    kw = {}
    for (k, (_, lo, hi, lg)), v in zip(FREE.items(), z):
        kw[k] = float(np.exp(v)) if lg else float(v)
    return replace(PhysicsParams(), **kw)


def _pack():
    z, lo, hi = [], [], []
    for _, (i, l, h, lg) in FREE.items():
        f = np.log if lg else (lambda x: x)
        z.append(f(i)); lo.append(f(l)); hi.append(f(h))
    return np.array(z), np.array(lo), np.array(hi)


def datasets():
    s94 = data.fig7a("SDS94")
    s94 = s94[s94[:, 0] > 0]
    tw = np.vstack([data.fig7a("TWEEN20_high_purity"), data.fig7a("TWEEN20_low_purity")])
    tw = tw[tw[:, 0] > 0]
    return {
        "table1": data.table1(),
        "fig7a_s94": np.c_[s94[:, 0], np.zeros(len(s94)), s94[:, 1]],
        "fig7a_tw": np.c_[np.zeros(len(tw)), tw[:, 0], tw[:, 1]],
        "s4a": data.figS4a(),
    }


def residuals(z, D):
    m = PhysicsModel(_unpack(z))
    out = []
    for key, arr in D.items():
        sig = SIG["fig7a"] if key.startswith("fig7a") else SIG[key]
        pred = np.array([m(s, t) for s, t, _ in arr])
        out.append((pred - arr[:, 2]) / sig)
    if USE_PRIORS:
        P = _unpack(z)
        pr = []
        for k, (kind, mu, sd) in PRIORS.items():
            v = getattr(P, k)
            pr.append(((np.log(v) if kind == "log" else v) - mu) / sd)
        out.append(np.array(pr))
    return np.concatenate(out)


def fit(D=None):
    D = D or datasets()
    z0, lo, hi = _pack()
    best = None
    rng = np.random.default_rng(0)
    for k in range(8):  # multistart
        start = z0 if k == 0 else lo + rng.random(len(z0)) * (hi - lo)
        r = least_squares(residuals, start, bounds=(lo, hi), args=(D,), x_scale="jac")
        if best is None or r.cost < best.cost:
            best = r
    return _unpack(best.x), best, D


def report(params, D):
    m = PhysicsModel(params)
    rep = {}
    for key, arr in D.items():
        pred = np.array([m(s, t) for s, t, _ in arr])
        e = pred - arr[:, 2]
        rep[key] = {"n": int(len(arr)), "rmse": round(float(np.sqrt((e ** 2).mean())), 2),
                    "max_abs": round(float(np.abs(e).max()), 2)}
    return rep


def main():
    params, res, D = fit()
    rep = report(params, D)
    # Laplace approximation in the transformed (log/lin) parameter space.
    J = res.jac
    cov = np.linalg.pinv(J.T @ J)
    out = {"model": "physics_v1", "params": params.to_dict(), "fit_report": rep,
           "free": list(FREE), "z_opt": res.x.tolist(), "cov_z": cov.tolist(),
           "cost": float(res.cost), "gamma_water": GAMMA_WATER,
           "note": "fitted to digitised figures; see data/digitized/README.md"}
    from pathlib import Path
    p = data.ROOT / "data" / "model"; p.mkdir(parents=True, exist_ok=True)
    (p / "physics_v1.json").write_text(json.dumps(out, indent=2))
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
