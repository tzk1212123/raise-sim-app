"""Dashboard state shared by the FastAPI server (server.py) and the in-browser
build (webapi.py, run under Pyodide on GitHub Pages). No web-framework imports here."""
from __future__ import annotations

import json
import threading
import time
from typing import Any, Dict, List, Optional

from .benchmark import evaluate, truth_table
from .config import SimConfig
from .experiment import Experiment, make_surface
from .planners import make_planner, run_campaign
from .planners.registry import LLM_CONTESTANTS, PROVIDERS as LLM_PROVIDERS, available as llm_available, \
    is_llm, label_of, model_of, provider_of, resolve as llm_resolve
from .task import T1

SURFACES = {"physics": ("physics", 0), "family1": ("family", 1), "family2": ("family", 2),
            "family3": ("family", 3), "gp": ("gp", 0)}
BASELINES = {
    "random": ("Random", "#9a968e", "Uniform random over untried grid points"),
    "ofat": ("OFAT (manual-style)", "#c58a2b", "Human-style one-factor-at-a-time: scan SDS, then Tween, then refine"),
    "bo_ts": ("BO · RAISE-like", "#2f6fde", "RAISE-like Bayesian optimisation: GP on desirability + Thompson sampling"),
    "bo_angle": ("BO · angle model", "#1f4fa8", "GP on contact angle; known surfactant-total term applied exactly"),
}
PLANNER_INFO = {k: v[2] for k, v in BASELINES.items()}
PLANNER_INFO.update({k: v["desc"] for k, v in LLM_CONTESTANTS.items()})
VAL_KEYS = ("true_theta", "true_D", "true_in_window", "regret", "val_angle_mean", "val_angle_sd", "val_in_window",
            "val_D", "first_truly_good_at")


class ApiError(Exception):
    def __init__(self, status: int, detail: str):
        super().__init__(detail)
        self.status, self.detail = status, detail


class StopCampaign(Exception):
    pass


def contestant_ok(name: str) -> bool:
    return name in PLANNER_INFO or (":" in name and provider_of(name) in LLM_PROVIDERS)


def contestants_meta():
    out = []
    for k, (label, color, desc) in BASELINES.items():
        out.append({"id": k, "label": label, "color": color, "desc": desc, "kind": "baseline", "available": True})
    for k, d in LLM_CONTESTANTS.items():
        prov = provider_of(k)
        out.append({"id": k, "label": d["label"], "color": d["color"], "desc": d["desc"], "kind": "llm",
                    "provider": prov or "anthropic", "model": model_of(k), "available": llm_available(k),
                    "key_env": LLM_PROVIDERS[prov]["key_env"] if prov else "ANTHROPIC_API_KEY"})
    return out


def _slim(r: Dict) -> Dict:
    return {"run_id": r["run_id"], "tag": r.get("tag"), "sds": r["set"]["sds_wv_pct"], "tween": r["set"]["tween_wv_pct"],
            "status": r["status"], "angle": r.get("contact_angle_mean"), "sd": r.get("contact_angle_sd"),
            "D": r.get("desirability"), "total": r.get("total_wv_pct"),
            "droplets": [d["angle_deg"] for d in r.get("droplets", [])], "duration_s": r.get("duration_s"),
            "error": r.get("error")}


def jsonable(x):
    return json.loads(json.dumps(x, default=str))


class Hub:
    """One shared simulated rig."""

    def __init__(self):
        self.lock = threading.RLock()
        self.new_rig("physics", 0, 1.0)
        self.campaign: Dict[str, Any] = {"state": "idle"}
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    # -- rig ---------------------------------------------------------------
    def new_rig(self, surface: str, seed: int, noise: float):
        kind, idx = SURFACES[surface]
        self.surface_name = surface
        self.seed, self.noise = seed, noise
        self.exp = Experiment(make_surface(kind, idx), SimConfig(seed=seed, noise_scale=noise))
        self.steps: List[Dict] = []
        self.exp.registry.listeners.append(self._on_write)
        self._truth_cache = None

    def _on_write(self, device, channel, value, result):
        if channel in ("tips_left_p20",):
            return
        v = value
        if isinstance(v, dict):
            v = {k: (round(x, 2) if isinstance(x, float) else x) for k, x in v.items() if k != "apparent"}
        self.steps.append({"t": round(self.exp.lab.clock_s, 1), "device": device, "action": channel,
                           "args": v, "result": result if isinstance(result, (int, float, str, type(None))) else None})
        self.steps = self.steps[-400:]

    def truth(self):
        if self._truth_cache is None:
            tt = truth_table(self.exp.lab.surface, T1)
            self._truth_cache = {
                "sds": sorted({s for s, _ in T1.grid()}), "tween": sorted({t for _, t in T1.grid()}),
                "cells": [{"sds": s, "tween": t, "theta": round(tt["theta"][(s, t)], 2), "D": round(tt["D"][(s, t)], 4),
                           "good": (s, t) in tt["good"]} for s, t in T1.grid()],
                "best": list(tt["best_in_window"]), "D_star": round(tt["D_star"], 4)}
        return self._truth_cache

    def deck(self) -> Dict:
        lab, c = self.exp.lab, self.exp.cfg
        spots = []
        for i in range(lab.spots_total):
            st, lv, pos = lab.spot(i)
            info = lab.spot_log.get(i)
            spots.append({"i": i, "stage": st, "level": lv, "pos": pos, "used": i < lab.spots_used,
                          "angle": info["angle"] if info else None})
        wells = [None if w is None else {"total": round(w.total, 1), "mixed": w.mixed,
                                         "sds": round(lab.concentrations(w)[0], 3), "tween": round(lab.concentrations(w)[1], 3)}
                 for w in lab.wells]
        return {"spots": spots, "wells": wells, "tips": dict(lab.tips), "tips_total": {"p20": c.tips_p20, "p300": c.tips_p300},
                "stocks": {k: round(v, 1) for k, v in lab.stocks.items()}, "stocks_total": dict(c.stock_volume_uL),
                "camera_attached": lab.camera_attached, "clock_s": round(lab.clock_s, 1),
                "manual_resets": lab.manual_resets, "human_min": round(lab.human_time_s / 60, 1),
                "levels": c.stage_levels, "positions": c.positions_per_level, "stages": c.stages,
                "env": dict(lab.env)}

    # -- plain endpoints ----------------------------------------------------
    def meta(self) -> Dict:
        planners = dict(PLANNER_INFO)
        avail = {k: (llm_available(k) if is_llm(k) else True) for k in planners}
        return {"task": self.exp.task_description(), "surfaces": list(SURFACES), "planners": planners, "available": avail,
                "contestants": contestants_meta(),
                "providers": {k: {"label": v["label"], "key_env": v["key_env"], "model_env": v["model_env"],
                                  "default_model": v["model"], "available": bool(llm_resolve(k)[1]),
                                  "route": llm_resolve(k)[2]}
                              for k, v in LLM_PROVIDERS.items()},
                "config": {k: v for k, v in self.exp.cfg.to_dict().items() if not isinstance(v, dict)},
                "devices": self.exp.registry.manifests()}

    def state(self) -> Dict:
        with self.lock:
            return {"surface": self.surface_name, "seed": self.seed, "noise_scale": self.noise, "deck": self.deck(),
                    "status": self.exp.status(), "history": [_slim(r) for r in self.exp.history[-200:]],
                    "steps": self.steps[-120:], "campaign_state": self.campaign.get("state")}

    def run_one(self, sds: float, tween: float) -> Dict:
        if self.campaign.get("state") == "running":
            raise ApiError(409, "stop the campaign first")
        with self.lock:
            self.steps = []
            rec = self.exp.run(sds, tween, tag="manual")
            return {"record": rec, "steps": self.steps}

    def reset(self, surface: str, seed: int, noise: float):
        if self.campaign.get("state") == "running":
            raise ApiError(409, "stop the campaign first")
        if surface not in SURFACES:
            raise ApiError(400, f"unknown surface {surface}")
        with self.lock:
            self.new_rig(surface, seed, noise)
            self.campaign = {"state": "idle"}

    def manual_reset(self):
        with self.lock:
            self.exp.registry.write("deck", "reset_batch")

    # -- campaign ------------------------------------------------------------
    def prepare_campaign(self, planner: str, budget: int, n_init: int, seed: int, fresh: bool):
        if planner not in PLANNER_INFO:
            raise ApiError(400, "unknown planner")
        with self.lock:
            if fresh:
                self.new_rig(self.surface_name, seed, self.noise)
            p = make_planner(planner, T1, seed=seed, **({"log": None} if is_llm(planner) else {}))
            start = len(self.exp.history)
        self._stop.clear()
        self.campaign = {"state": "running", "planner": planner, "budget": budget, "n_init": n_init, "seed": seed,
                         "start": start, "recommendation": None, "validation": None, "error": None,
                         "started_at": time.time(), "_planner": p}
        return p

    def execute_campaign(self, p, pace=None):
        """Run the prepared campaign to the end (blocking)."""
        c = self.campaign
        if pace:
            self.exp.listeners.append(pace)
        try:
            res = run_campaign(self.exp, p, c["budget"], n_init=c["n_init"], seed=c["seed"])
            c["recommendation"] = res["recommendation"]
            c["notes"] = jsonable(res["notes"])
            c["state"] = "done"
            self.validate()
        except StopCampaign:
            c["state"] = "stopped"
            c["recommendation"] = p.recommend(self.exp.history[c["start"]:]) if not hasattr(p, "run_agent") else None
        except Exception as e:  # show errors in the UI instead of dying silently
            c["state"] = "error"
            c["error"] = f"{type(e).__name__}: {e}"
        finally:
            if pace:
                self.exp.listeners.remove(pace)

    def start_campaign(self, planner: str, budget: int, n_init: int, seed: int, delay: float, fresh: bool):
        if self._thread and self._thread.is_alive():
            raise ApiError(409, "a campaign is already running")
        p = self.prepare_campaign(planner, budget, n_init, seed, fresh)

        def pace(_msg):
            if self._stop.is_set():
                raise StopCampaign()
            if delay > 0:
                time.sleep(delay)

        self._thread = threading.Thread(target=self.execute_campaign, args=(p, pace), daemon=True)
        self._thread.start()

    def validate(self, n_val: int = 5):
        rec = self.campaign.get("recommendation")
        if not rec:
            return
        hist = self.exp.history[self.campaign["start"]:]
        res = {"planner": self.campaign["planner"], "budget": self.campaign["budget"], "seed": self.campaign["seed"],
               "history": hist, "recommendation": tuple(rec)}
        tt = truth_table(self.exp.lab.surface, T1)
        m = evaluate(res, self.exp.lab.surface, tt, T1, self.exp.cfg, n_val, val_seed=99_000 + self.campaign["seed"])
        self.campaign["validation"] = {k: m.get(k) for k in VAL_KEYS}
        self.campaign["validation"]["D_star"] = round(tt["D_star"], 4)
        self.campaign["validation"]["best_in_window"] = list(tt["best_in_window"])

    def campaign_view(self) -> Dict:
        c = {k: v for k, v in self.campaign.items() if not k.startswith("_")}
        if "start" in c:
            c["history"] = [_slim(r) for r in self.exp.history[c["start"]:]]
        p = self.campaign.get("_planner")
        if p is not None and hasattr(p, "transcript_text"):
            c["thoughts"] = p.transcript_text[-60:]
            c["usage"] = getattr(p, "usage", None)
        return jsonable(c)


# ---------------------------------------------------------------- planner race
def race_lane(hub: Hub, name: str, seed: int):
    exp = Experiment(hub.exp.lab.surface, SimConfig(seed=seed, noise_scale=hub.noise))
    p = make_planner(name, T1, seed=seed, **({"log": None} if is_llm(name) else {}))
    return {"planner": name, "state": "running", "exp": exp, "p": p, "rec": None, "val": None, "error": None}


def race_meta(hub: Hub, budget: int, n_init: int, seed: int):
    tt = truth_table(hub.exp.lab.surface, T1)
    return tt, {"budget": budget, "seed": seed, "n_init": n_init, "D_star": round(tt["D_star"], 4),
                "best": list(tt["best_in_window"])}


def run_lane(lane: Dict, budget: int, n_init: int, seed: int, tt, pace=None):
    """Run one race lane to the end (blocking), then validate its answer."""
    exp = lane["exp"]
    if pace:
        exp.listeners.append(pace)
    try:
        res = run_campaign(exp, lane["p"], budget, n_init=n_init, seed=seed)
        lane["rec"] = res["recommendation"]
        if pace:
            exp.listeners.remove(pace)
            pace = None
        lane["state"] = "validating"
        m = evaluate(res, exp.lab.surface, tt, T1, exp.cfg, 5, val_seed=99_000 + seed)
        lane["val"] = {k: m.get(k) for k in ("true_theta", "true_D", "true_in_window", "regret",
                                             "val_angle_mean", "val_in_window", "val_D")}
        lane["state"] = "done"
    except StopCampaign:
        lane["state"] = "stopped"
    except Exception as e:
        lane["state"], lane["error"] = "error", f"{type(e).__name__}: {e}"
    finally:
        if pace:
            exp.listeners.remove(pace)


def lane_view(ln: Dict) -> Dict:
    exp, p = ln["exp"], ln["p"]
    return {"planner": ln["planner"], "state": ln["state"], "error": ln["error"],
            "history": [_slim(r) for r in exp.history],
            "recommendation": ln["rec"], "validation": ln["val"],
            "sim_minutes": round(exp.lab.clock_s / 60, 1),
            "material_pct": round(sum(r["set"]["sds_wv_pct"] + r["set"]["tween_wv_pct"] for r in exp.history), 2),
            "thoughts": getattr(p, "transcript_text", [])[-3:],
            "thought_log": getattr(p, "thought_log", [])[-80:],
            "label": label_of(ln["planner"]), "model": model_of(ln["planner"]),
            "usage": getattr(p, "usage", None)}
