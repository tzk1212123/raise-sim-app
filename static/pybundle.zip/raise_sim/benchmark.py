"""Benchmark runner: planners x surfaces x seeds x budgets, with a validation phase.

    python -m raise_sim.benchmark --planners random ofat bo_ts bo_angle --budgets 15 30 \
        --seeds 5 --surfaces physics family:4 gp --out reports/benchmark

Headline metric is DELIVERED performance (project doc): after the search each
planner recommends one formulation, which is re-tested in `n_val` fresh
experiments on a fresh rig (new substrates, new noise). We also score the
recommendation on the noise-free ground truth. The best observed search value
is reported only as a secondary number.
"""
from __future__ import annotations

import argparse
import json
import math
import time
from concurrent.futures import ProcessPoolExecutor
from dataclasses import replace
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np

from .config import SimConfig
from .experiment import Experiment, make_surface
from .planners import make_planner, run_campaign
from .task import T1, Task


def surface_specs(tokens: List[str]):
    out = []
    for tok in tokens:
        if tok.startswith("family:"):
            out += [("family", i) for i in range(1, int(tok.split(":")[1]) + 1)]
        else:
            out.append((tok, 0))
    return out


def truth_table(surface, task: Task) -> Dict:
    pts = task.grid()
    th = {p: float(surface(*p)) for p in pts}
    d = {p: task.desirability(th[p], *p) for p in pts}
    ok = [p for p in pts if task.window[0] <= th[p] <= task.window[1]]
    best_ok = max(ok, key=lambda p: d[p]) if ok else max(pts, key=lambda p: d[p])
    good = {p for p in ok if d[p] >= task.optimal_desirability}
    return {"theta": th, "D": d, "best_in_window": best_ok, "D_star": d[best_ok], "good": good}


def evaluate(result: Dict, surface, truth: Dict, task: Task, cfg: SimConfig, n_val: int, val_seed: int) -> Dict:
    hist = result["history"]
    rec = result["recommendation"]
    m: Dict = {"planner": result["planner"], "budget": result["budget"], "seed": result["seed"]}
    m["n_failed_or_partial"] = sum(r["status"] != "ok" for r in hist)
    m["n_invalid"] = sum(r["status"] in ("rejected", "infeasible", "device_error") for r in hist)
    m["n_unique"] = len({(r["set"]["sds_wv_pct"], r["set"]["tween_wv_pct"]) for r in hist})
    good_idx = [i + 1 for i, r in enumerate(hist)
                if (r["set"]["sds_wv_pct"], r["set"]["tween_wv_pct"]) in truth["good"]]
    m["first_truly_good_at"] = good_idx[0] if good_idx else None
    obsD = [r["desirability"] for r in hist if r.get("desirability") is not None]
    m["best_observed_D"] = max(obsD) if obsD else None
    if rec is None:
        m.update({"rec": None, "true_theta": None, "true_D": 0.0, "true_in_window": False, "regret": truth["D_star"]})
        return m
    s, t = rec
    th = float(surface(s, t))
    dtrue = task.desirability(th, s, t)
    inw = task.window[0] <= th <= task.window[1]
    m.update({"rec": [s, t], "rec_total": round(s + t, 2), "true_theta": round(th, 2), "true_D": round(dtrue, 4),
              "true_in_window": bool(inw),
              "regret": round(truth["D_star"] - (dtrue if inw else 0.0), 4)})
    # validation on a fresh rig
    vexp = Experiment(surface, replace(cfg, seed=val_seed, data_dir=None), task)
    vals = [vexp.run(s, t, tag="validation") for _ in range(n_val)]
    angles = [v["contact_angle_mean"] for v in vals if v["contact_angle_mean"] is not None]
    if angles:
        mu = float(np.mean(angles))
        m.update({"val_angle_mean": round(mu, 2), "val_angle_sd": round(float(np.std(angles, ddof=1)), 2) if len(angles) > 1 else None,
                  "val_in_window": bool(task.window[0] <= mu <= task.window[1]),
                  "val_D": round(task.desirability(mu, s, t), 4), "val_n": len(angles)})
    else:
        m.update({"val_angle_mean": None, "val_in_window": False, "val_D": 0.0, "val_n": 0})
    return m


def _job(args):
    planner_name, kind, idx, budget, seed, n_init, n_val, cfg_over, llm_kw = args
    surface = make_surface(kind, idx)
    task = T1
    cfg = SimConfig(seed=1000 * seed + 17 * idx + budget, **cfg_over)
    exp = Experiment(surface, cfg, task)
    from .planners.registry import is_llm
    planner = make_planner(planner_name, task, seed=seed, **(llm_kw if is_llm(planner_name) else {}))
    t0 = time.time()
    res = run_campaign(exp, planner, budget, n_init=n_init, seed=seed)
    truth = truth_table(surface, task)
    m = evaluate(res, surface, truth, task, cfg, n_val, val_seed=99_000 + seed)
    m.update({"surface": f"{kind}{idx if kind == 'family' else ''}", "wall_s": round(time.time() - t0, 2),
              "sim_minutes": round(exp.lab.clock_s / 60, 1), "manual_resets": exp.lab.manual_resets,
              "human_minutes": round(exp.lab.human_time_s / 60, 1), "notes": res["notes"],
              "D_star": round(truth["D_star"], 4), "best_in_window": list(truth["best_in_window"])})
    trace = [{"i": i + 1, "set": r["set"], "status": r["status"], "angle": r.get("contact_angle_mean"),
              "D": r.get("desirability")} for i, r in enumerate(res["history"])]
    return m, trace


def summarise(rows: List[Dict]) -> List[Dict]:
    out = []
    keys = sorted({(r["planner"], r["budget"]) for r in rows})
    for p, b in keys:
        g = [r for r in rows if r["planner"] == p and r["budget"] == b]
        n = len(g)

        def ms(vals):
            vals = [v for v in vals if v is not None]
            if not vals:
                return None, None
            return float(np.mean(vals)), (float(np.std(vals, ddof=1) / math.sqrt(len(vals))) if len(vals) > 1 else 0.0)

        hit, hit_se = ms([float(r["true_in_window"]) for r in g])
        vhit, vhit_se = ms([float(r["val_in_window"]) for r in g])
        reg, reg_se = ms([r["regret"] for r in g])
        vD, vD_se = ms([r.get("val_D") for r in g])
        found = [r["first_truly_good_at"] for r in g]
        out.append({"planner": p, "budget": b, "n_campaigns": n,
                    "true_hit_rate": hit, "true_hit_se": hit_se,
                    "val_hit_rate": vhit, "val_hit_se": vhit_se,
                    "regret_mean": reg, "regret_se": reg_se,
                    "val_D_mean": vD, "val_D_se": vD_se,
                    "found_good_frac": sum(f is not None for f in found) / n,
                    "median_first_good": float(np.median([f for f in found if f is not None])) if any(f is not None for f in found) else None,
                    "failed_runs_mean": float(np.mean([r["n_failed_or_partial"] for r in g])),
                    "sim_minutes_mean": float(np.mean([r["sim_minutes"] for r in g]))})
    return out


def to_markdown(summary: List[Dict]) -> str:
    f = lambda m, s, k=2: "—" if m is None else (f"{m:.{k}f} ± {s:.{k}f}" if s is not None else f"{m:.{k}f}")
    lines = ["| planner | budget | n | true hit-rate | validated hit-rate | regret (true D) | validated D | found a good point | median 1st good | failed runs | sim min |",
             "|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in summary:
        lines.append(f"| {r['planner']} | {r['budget']} | {r['n_campaigns']} | {f(r['true_hit_rate'], r['true_hit_se'])} | "
                     f"{f(r['val_hit_rate'], r['val_hit_se'])} | {f(r['regret_mean'], r['regret_se'], 3)} | "
                     f"{f(r['val_D_mean'], r['val_D_se'], 3)} | {r['found_good_frac']:.2f} | "
                     f"{'—' if r['median_first_good'] is None else int(r['median_first_good'])} | "
                     f"{r['failed_runs_mean']:.1f} | {r['sim_minutes_mean']:.0f} |")
    return "\n".join(lines)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--planners", nargs="+", default=["random", "ofat", "bo_ts", "bo_angle"])
    ap.add_argument("--budgets", nargs="+", type=int, default=[15, 30])
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--surfaces", nargs="+", default=["physics", "family:4", "gp"])
    ap.add_argument("--n-init", type=int, default=3)
    ap.add_argument("--n-val", type=int, default=5)
    ap.add_argument("--noise-scale", type=float, default=1.0)
    ap.add_argument("--workers", type=int, default=0, help="0 = cpu count")
    ap.add_argument("--llm-model", default=None)
    ap.add_argument("--llm-effort", default=None, help="default: medium (Claude), high (DeepSeek)")
    ap.add_argument("--out", default="reports/benchmark")
    a = ap.parse_args(argv)
    llm_kw = {"log": None}
    if a.llm_effort:
        llm_kw["effort"] = a.llm_effort
    if a.llm_model:
        llm_kw["model"] = a.llm_model
    jobs = [(p, k, i, b, s, a.n_init, a.n_val, {"noise_scale": a.noise_scale}, llm_kw)
            for p in a.planners for (k, i) in surface_specs(a.surfaces) for b in a.budgets for s in range(a.seeds)]
    print(f"{len(jobs)} campaigns")
    t0 = time.time()
    rows, traces = [], []
    if a.workers == 1 or any(p.startswith("llm") for p in a.planners):   # Claude runs serially
        results = map(_job, jobs)
    else:
        ex = ProcessPoolExecutor(max_workers=a.workers or None)
        results = ex.map(_job, jobs, chunksize=1)
    for k, (m, tr) in enumerate(results, 1):
        rows.append(m)
        traces.append({"planner": m["planner"], "budget": m["budget"], "seed": m["seed"], "surface": m["surface"], "trace": tr})
        if k % 10 == 0 or k == len(jobs):
            print(f"  {k}/{len(jobs)} done ({time.time() - t0:.0f}s)")
    summ = summarise(rows)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    (out / "campaigns.json").write_text(json.dumps(rows, indent=1, default=str), encoding="utf-8")
    (out / "traces.json").write_text(json.dumps(traces, default=str), encoding="utf-8")
    (out / "summary.json").write_text(json.dumps(summ, indent=1), encoding="utf-8")
    md = to_markdown(summ)
    (out / "summary.md").write_text(
        f"# Benchmark summary\n\nargs: `{vars(a)}`\n\n{md}\n\n"
        "true hit-rate: recommended formulation's noise-free angle lies in 70.39-73.61 deg. "
        "validated: mean of n_val fresh experiments in the window. regret: D* (best in-window grid point) minus "
        "true D of the recommendation (0 if outside the window). Mean ± SE over campaigns.\n", encoding="utf-8")
    print(md)


if __name__ == "__main__":
    main()
