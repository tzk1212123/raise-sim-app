"""Simulated RAISE rig: OT-2 + deck + pick-and-place camera + image analyser.

`SimLab` holds the hidden state (clock, liquids, consumables, the true contact
angle surface). `build_devices` exposes it as MHS-style devices, and
`Protocol` runs one formulation through those devices exactly as the RAISE
orchestrator does: calculate volumes -> dispense -> mix -> deposit droplets ->
pick up camera -> wait -> capture -> analyse (retry once) -> return camera.

Planners never touch this module directly; they go through experiment.Experiment.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np

from .config import SimConfig
from .measurement import MeasurementModel
from .mhs import Channel, Device, DeviceError, Registry

Surface = Callable[[float, float], float]   # (sds % w/v, tween % w/v) -> true angle (deg)


@dataclass
class Well:
    volumes: Dict[str, float] = field(default_factory=dict)   # liquid -> uL
    mixed: bool = False

    @property
    def total(self) -> float:
        return sum(self.volumes.values())


class SimLab:
    """Hidden ground truth of the rig."""

    def __init__(self, surface: Surface, cfg: Optional[SimConfig] = None):
        self.cfg = cfg or SimConfig()
        self.surface = surface
        self.rng = np.random.default_rng(self.cfg.seed)
        self.meas = MeasurementModel(self.cfg, self.rng)
        self.clock_s = 0.0
        self.manual_resets = 0
        self.human_time_s = 0.0
        self.tip_on: Dict[str, bool] = {"p20": False, "p300": False}
        self.camera_attached = False
        self.images: Dict[int, Dict] = {}
        self._img_id = 0
        self.env = {"temperature_C": 22.0, "humidity_pct": 35.0}
        self._reset_consumables(initial=True)

    # -- consumables -------------------------------------------------------
    def _reset_consumables(self, initial: bool = False) -> None:
        c = self.cfg
        self.stocks = dict(c.stock_volume_uL) if initial else self.stocks
        self.wells: List[Optional[Well]] = [None] * c.plate_wells
        self.tips = {"p20": c.tips_p20, "p300": c.tips_p300}
        self.spots_used = 0
        self.spot_log: Dict[int, Dict] = {}   # spot index -> what was measured there (for displays)
        if not initial:
            for s in range(c.stages):
                self.meas.install_substrate(s)

    def manual_reset(self) -> None:
        """Human batch reset: new substrates, plate, tip racks; stocks refilled."""
        self.manual_resets += 1
        self.human_time_s += self.cfg.t_manual_reset_s
        self.stocks = dict(self.cfg.stock_volume_uL)
        self._reset_consumables()

    @property
    def spots_total(self) -> int:
        c = self.cfg
        return c.stages * c.stage_levels * c.positions_per_level

    def spot(self, index: int) -> Tuple[int, int, int]:
        c = self.cfg
        per_stage = c.stage_levels * c.positions_per_level
        st, r = divmod(index, per_stage)
        lv, pos = divmod(r, c.positions_per_level)
        return st, lv, pos

    def tick(self, seconds: float) -> None:
        self.clock_s += seconds
        self.env["temperature_C"] = float(np.clip(self.env["temperature_C"] + self.rng.normal(0, 0.02), 20, 24))
        self.env["humidity_pct"] = float(np.clip(self.env["humidity_pct"] + self.rng.normal(0, 0.1), 20, 60))

    # -- liquid handling ---------------------------------------------------
    def pipette_error(self, pipette: str, v: float) -> float:
        if not self.cfg.pipette_noise or self.cfg.noise_scale == 0:
            return v
        cv = (0.01 + 0.04 / math.sqrt(v)) if pipette == "p20" else (0.006 + 0.1 / math.sqrt(v))
        return max(0.0, v * (1 + self.rng.normal(0, cv)))

    def concentrations(self, well: Well) -> Tuple[float, float]:
        tot = well.total
        if tot <= 0:
            return 0.0, 0.0
        s = well.volumes.get("sds", 0.0) * self.cfg.stock_sds_wv / tot
        t = well.volumes.get("tween", 0.0) * self.cfg.stock_tween_wv / tot
        return s, t


def build_devices(lab: SimLab) -> Registry:
    c = lab.cfg

    def need_tip(p):
        if not lab.tip_on[p]:
            raise DeviceError(f"{p} has no tip attached")

    def pick_tip(p):
        if lab.tip_on[p]:
            raise DeviceError(f"{p} already holds a tip")
        if lab.tips[p] <= 0:
            raise DeviceError(f"{p} tip rack empty")
        lab.tips[p] -= 1
        lab.tip_on[p] = True
        lab.tick(c.t_tip_pick)

    def drop_tip(p):
        need_tip(p)
        lab.tip_on[p] = False
        lab.tick(c.t_tip_drop)

    def well_at(i) -> Well:
        if not (0 <= i < c.plate_wells):
            raise DeviceError(f"well {i} does not exist")
        if lab.wells[i] is None:
            lab.wells[i] = Well()
        return lab.wells[i]

    def transfer(p, arg):
        need_tip(p)
        src, dst, v = arg["source"], int(arg["dest_well"]), float(arg["volume_uL"])
        if lab.stocks.get(src, 0.0) < v:
            raise DeviceError(f"insufficient {src} stock ({lab.stocks.get(src, 0):.0f} uL left)")
        w = well_at(dst)
        if w.total + v > c.well_capacity_uL:
            raise DeviceError(f"well {dst} would overflow")
        delivered = lab.pipette_error(p, v)
        lab.stocks[src] -= v
        w.volumes[src] = w.volumes.get(src, 0.0) + delivered
        w.mixed = False
        lab.tick(c.t_transfer)
        return round(delivered, 3)

    def mix(arg):
        need_tip("p300")
        w = well_at(int(arg["well"]))
        if w.total < arg["volume_uL"]:
            raise DeviceError("mix volume exceeds well contents (would aspirate air)")
        w.mixed = True
        lab.tick(c.t_mix_cycle * int(arg["cycles"]))

    def deposit(arg):
        need_tip("p20")
        w = well_at(int(arg["well"]))
        if not w.mixed:
            raise DeviceError("well not mixed before droplet deposition")
        v = float(arg["volume_uL"])
        if w.total < v:
            raise DeviceError("well empty")
        frac = (w.total - v) / w.total
        for k in w.volumes:
            w.volumes[k] *= frac
        lab.tick(c.t_droplet_deposit)

    def pick_camera(_=None):
        if lab.camera_attached:
            raise DeviceError("camera already attached")
        lab.camera_attached = True
        lab.tick(c.t_camera_pick)

    def return_camera(_=None):
        if not lab.camera_attached:
            raise DeviceError("camera not attached")
        lab.camera_attached = False
        lab.tick(c.t_camera_return)

    def move_camera(arg):
        if not lab.camera_attached:
            raise DeviceError("camera not attached")
        lab.tick(c.t_camera_move)

    def wait(s):
        lab.tick(float(s))

    ot2 = Device(
        "ot2", "liquid_handler",
        "Simulated Opentrons OT-2 with P20 and P300 single-channel GEN2 pipettes, "
        "a pick-and-place camera holder and a stepped imaging stage.",
        tags=["transfers outside the pipette's rated range are rejected by the device",
              "every liquid contact needs a fresh tip; tips are counted",
              "the camera is carried by the P300 mount via an end-cut tip adapter"],
        channels=[
            Channel("pick_tip_p20", "action", "", "pick up a P20 tip", write_fn=lambda _=None: pick_tip("p20")),
            Channel("pick_tip_p300", "action", "", "pick up a P300 tip", write_fn=lambda _=None: pick_tip("p300")),
            Channel("drop_tip_p20", "action", "", "drop the P20 tip", write_fn=lambda _=None: drop_tip("p20")),
            Channel("drop_tip_p300", "action", "", "drop the P300 tip", write_fn=lambda _=None: drop_tip("p300")),
            Channel("transfer_p20", "action", "uL", "{source, dest_well, volume_uL}",
                    limits=c.p20_range_uL, write_fn=lambda a: transfer("p20", a)),
            Channel("transfer_p300", "action", "uL", "{source, dest_well, volume_uL}",
                    limits=c.p300_range_uL, write_fn=lambda a: transfer("p300", a)),
            Channel("mix_p300", "action", "uL", "{well, cycles, volume_uL}",
                    limits=c.p300_range_uL, write_fn=mix),
            Channel("deposit_droplet_p20", "action", "uL", "{well, stage, level, position, volume_uL}",
                    limits=c.p20_range_uL, write_fn=deposit),
            Channel("pick_camera", "action", "", "attach the camera adapter", write_fn=pick_camera),
            Channel("return_camera", "action", "", "return the camera to its base", write_fn=return_camera),
            Channel("move_camera", "action", "", "{stage, level, position}", write_fn=move_camera),
            Channel("wait", "action", "s", "idle", limits=(0, 600), write_fn=wait),
            Channel("tips_left_p20", "read", "", "", read_fn=lambda: lab.tips["p20"]),
            Channel("tips_left_p300", "read", "", "", read_fn=lambda: lab.tips["p300"]),
            Channel("camera_attached", "read", "0/1", "", read_fn=lambda: int(lab.camera_attached)),
        ])

    def free_well():
        for i, w in enumerate(lab.wells):
            if w is None:
                return i
        return None

    deck = Device(
        "deck", "deck_state",
        "Consumable state: 96-well mixing plate, two stepped stages (5 levels x 9 positions each), stocks.",
        tags=["stage spots are single-use; a batch holds 90 droplets (30 formulations x 3)",
              "reset_batch is a MANUAL step (new substrates, plate, tips, refilled stocks)"],
        channels=[
            Channel("next_free_well", "read", "", "", read_fn=free_well),
            Channel("free_spots", "read", "", "", read_fn=lambda: lab.spots_total - lab.spots_used),
            Channel("stocks_uL", "read", "uL", "", read_fn=lambda: {k: round(v, 1) for k, v in lab.stocks.items()}),
            Channel("manual_resets", "read", "", "", read_fn=lambda: lab.manual_resets),
            Channel("reset_batch", "action", "", "manual batch reset", write_fn=lambda _=None: lab.manual_reset()),
        ])

    def capture(arg):
        if not lab.camera_attached:
            raise DeviceError("camera not attached")
        lab._img_id += 1
        lab.images[lab._img_id] = dict(arg)
        lab.tick(c.t_capture)
        return lab._img_id

    camera = Device(
        "camera-1", "camera", "USB side-view camera (OpenCV capture) on the pick-and-place holder.",
        tags=["capture needs the camera attached and positioned"],
        channels=[Channel("capture", "action", "", "-> image id", write_fn=capture)])

    def analyse(arg):
        img = lab.images[int(arg["image_id"])]
        return lab.meas.analyse(img["apparent"], int(arg.get("attempt", 0)))[0]

    analyser = Device(
        "analyser", "image_analysis",
        "Contour detection + Bashforth-Adams fit; returns the static contact angle or None if no droplet contour.",
        tags=["None means a failed detection: retry, never record as a number"],
        channels=[Channel("analyse", "action", "deg", "{image_id, attempt}", write_fn=analyse)])

    env = Device(
        "env", "environment_sensor", "Ambient temperature and humidity display.",
        channels=[Channel("temperature_C", "read", "C", "", read_fn=lambda: round(lab.env["temperature_C"], 2)),
                  Channel("humidity_pct", "read", "%", "", read_fn=lambda: round(lab.env["humidity_pct"], 1))])

    return Registry([ot2, deck, camera, analyser, env])


class InfeasibleFormulation(ValueError):
    """Requested composition cannot be prepared with the configured stocks/pipettes."""


class Protocol:
    """RAISE static contact-angle protocol, driven only through the device registry
    (plus the hidden SimLab for ground-truth bookkeeping)."""

    def __init__(self, lab: SimLab, reg: Registry):
        self.lab, self.reg, self.cfg = lab, reg, lab.cfg

    def plan_volumes(self, sds: float, tween: float) -> Dict[str, float]:
        c = self.cfg
        V = c.mixture_volume_uL
        v = {"sds": sds * V / c.stock_sds_wv, "tween": tween * V / c.stock_tween_wv}
        v["water"] = V - v["sds"] - v["tween"]
        if v["water"] < 0:
            raise InfeasibleFormulation("stocks too dilute for this composition")
        for k, x in v.items():
            if 0 < x < c.p20_range_uL[0]:
                raise InfeasibleFormulation(f"{k} volume {x:.2f} uL below the smallest pipettable volume")
        return {k: round(x, 3) for k, x in v.items()}

    def _transfer(self, src: str, well: int, v: float, log: List) -> None:
        if v <= 0:
            return
        p = "p20" if v <= self.cfg.p20_range_uL[1] else "p300"
        self.reg.write("ot2", f"pick_tip_{p}")
        d = self.reg.write("ot2", f"transfer_{p}", {"source": src, "dest_well": well, "volume_uL": v})
        self.reg.write("ot2", f"drop_tip_{p}")
        log.append({"step": "transfer", "source": src, "pipette": p, "requested_uL": v, "delivered_uL": d})

    def _ensure_capacity(self, log: List) -> None:
        lab, c = self.lab, self.cfg
        need_tips = {"p20": 3, "p300": 4}
        short = (self.reg.read("deck", "next_free_well") is None
                 or self.reg.read("deck", "free_spots") < c.droplets
                 or any(lab.tips[p] < n for p, n in need_tips.items())
                 or any(lab.stocks[k] < c.mixture_volume_uL for k in lab.stocks))
        if short:
            if not c.auto_reset:
                raise DeviceError("consumables depleted: manual batch reset required")
            self.reg.write("deck", "reset_batch")
            log.append({"step": "manual_reset"})

    def run(self, sds: float, tween: float) -> Dict:
        lab, c, reg = self.lab, self.cfg, self.reg
        t0 = lab.clock_s
        log: List[Dict] = []
        vols = self.plan_volumes(sds, tween)
        self._ensure_capacity(log)
        well = reg.read("deck", "next_free_well")
        self._transfer("water", well, vols["water"], log)
        self._transfer("sds", well, vols["sds"], log)
        self._transfer("tween", well, vols["tween"], log)
        reg.write("ot2", "pick_tip_p300")
        reg.write("ot2", "mix_p300", {"well": well, "cycles": c.mix_cycles, "volume_uL": c.mix_volume_uL})
        reg.write("ot2", "drop_tip_p300")
        s_act, t_act = lab.concentrations(lab.wells[well])
        theta_true = float(lab.surface(s_act, t_act))
        spots = []
        reg.write("ot2", "pick_tip_p20")
        for _ in range(c.droplets):
            st, lv, pos = lab.spot(lab.spots_used)
            lab.spots_used += 1
            reg.write("ot2", "deposit_droplet_p20", {"well": well, "stage": st, "level": lv,
                                                     "position": pos, "volume_uL": c.droplet_volume_uL})
            age = lab.meas.place_droplet(st)
            spots.append((st, lv, pos, lab.meas.apparent_angle(theta_true, s_act, t_act, st, lv, age)))
        reg.write("ot2", "drop_tip_p20")
        reg.write("ot2", "pick_camera")
        droplets, truth = [], []
        first_spot = lab.spots_used - len(spots)
        for k, (st, lv, pos, apparent) in enumerate(spots):
            reg.write("ot2", "move_camera", {"stage": st, "level": lv, "position": pos})
            reg.write("ot2", "wait", c.capture_wait_s)
            angle, attempt = None, 0
            while True:
                img = reg.write("camera-1", "capture", {"apparent": apparent, "stage": st, "level": lv})
                angle, outlier = lab.meas.analyse(apparent, attempt)
                if angle is not None or attempt >= c.max_retries:
                    break
                attempt += 1
                reg.write("ot2", "wait", c.retry_extra_wait_s)
            droplets.append({"angle_deg": None if angle is None else round(angle, 2),
                             "status": "ok" if angle is not None else "failed", "retries": attempt,
                             "stage": st, "level": lv, "position": pos})
            truth.append({"apparent_deg": round(apparent, 3), "outlier": bool(outlier and angle is not None)})
            lab.spot_log[first_spot + k] = {"sds": sds, "tween": tween, "well": well,
                                            "angle": None if angle is None else round(angle, 2)}
        reg.write("ot2", "return_camera")
        vals = [d["angle_deg"] for d in droplets if d["angle_deg"] is not None]
        status = "ok" if len(vals) == c.droplets else ("partial" if vals else "failed")
        return {
            "status": status,
            "contact_angle_mean": round(float(np.mean(vals)), 2) if vals else None,
            "contact_angle_sd": round(float(np.std(vals, ddof=1)), 2) if len(vals) > 1 else None,
            "n_valid": len(vals),
            "droplets": droplets,
            "actual_wv_pct": {"sds": round(s_act, 4), "tween": round(t_act, 4)},
            "volumes_uL": vols,
            "well": well,
            "duration_s": round(lab.clock_s - t0, 1),
            "env": {"temperature_C": reg.read("env", "temperature_C"), "humidity_pct": reg.read("env", "humidity_pct")},
            "steps": log,
            "_truth": {"theta_true_at_actual": round(theta_true, 3), "droplets": truth},
        }
