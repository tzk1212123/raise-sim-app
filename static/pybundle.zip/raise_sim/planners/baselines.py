"""Random and one-factor-at-a-time (OFAT) baselines."""
from __future__ import annotations

from typing import Dict, List, Sequence

from .base import Planner, Point, observations


class RandomPlanner(Planner):
    name = "random"

    def suggest(self, history: Sequence[Dict]) -> Point:
        cand = self.untried(history) or self.grid
        return self.rng.choice(cand)


class OFATPlanner(Planner):
    """Human-style one-factor-at-a-time search.

    1. start from the best initial formulation;
    2. scan SDS on a coarse ladder at fixed Tween, keep the best;
    3. scan Tween on a coarse ladder at that SDS, keep the best;
    4. refine with single grid steps around the incumbent, then shrink to random.
    """
    name = "ofat"

    def __init__(self, task, seed: int = 0, sds_stride: int = 2, tween_stride: int = 3):
        super().__init__(task, seed)
        self.sds_levels = sorted({s for s, _ in self.grid})
        self.tween_levels = sorted({t for _, t in self.grid})
        self.sds_stride, self.tween_stride = sds_stride, tween_stride
        self.queue: List[Point] = []
        self.phase = "start"

    def _best(self, history) -> Point:
        obs = observations(history)
        if not obs:
            return self.rng.choice(self.grid)
        b = max(obs, key=lambda o: o.desirability)
        return b.sds, b.tween

    def _refill(self, history) -> None:
        s0, t0 = self._best(history)
        done = {(r["set"]["sds_wv_pct"], r["set"]["tween_wv_pct"]) for r in history}
        if self.phase == "start":
            self.phase = "scan_sds"
            self.queue = [(s, t0) for s in self.sds_levels[::self.sds_stride]]
        elif self.phase == "scan_sds":
            self.phase = "scan_tween"
            self.queue = [(s0, t) for t in self.tween_levels[::self.tween_stride]]
        else:
            self.phase = "refine"
            i, j = self.sds_levels.index(s0), self.tween_levels.index(t0)
            nb = []
            for di, dj in ((-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (1, 1), (-1, 1), (1, -1)):
                a, b = i + di, j + dj
                if 0 <= a < len(self.sds_levels) and 0 <= b < len(self.tween_levels):
                    nb.append((self.sds_levels[a], self.tween_levels[b]))
            self.queue = nb
        self.queue = [p for p in self.queue if p not in done]

    def suggest(self, history: Sequence[Dict]) -> Point:
        for _ in range(4):
            done = {(r["set"]["sds_wv_pct"], r["set"]["tween_wv_pct"]) for r in history}
            self.queue = [p for p in self.queue if p not in done]
            if self.queue:
                return self.queue.pop(0)
            before = self.phase
            self._refill(history)
            if self.phase == "refine" and before == "refine" and not self.queue:
                break
        cand = self.untried(history) or self.grid
        return self.rng.choice(cand)

    def notes(self) -> Dict:
        return {"final_phase": self.phase}
