"""Registry of LLM contestants and OpenAI-compatible providers.

Model IDs change often, so every provider's default model can be overridden by an
environment variable (e.g. QWEN_MODEL=qwen3-max). Any model can also be used
ad hoc with the contestant name "<provider>:<model id>", e.g. "openrouter:qwen/qwen3-32b".

Shared relay: if a provider's own key is missing but SMOLPROXY_API_KEY is set, the
provider is reached through https://smolproxy.org/<path> (OpenAI-compatible chat
completions). Set SMOLPROXY_BASE_URL to use another host. A provider's own key wins.

Base URLs checked 2026-11-05 (official docs where available, otherwise widely used
compatibility guides). Defaults are deliberately long-lived aliases where they exist.
"""
from __future__ import annotations

import os
from typing import Dict, Optional

PROVIDERS: Dict[str, Dict] = {
    "deepseek": {"label": "DeepSeek", "base_url": "https://api.deepseek.com", "key_env": "DEEPSEEK_API_KEY",
                 "model_env": "DEEPSEEK_MODEL", "model": "deepseek-flash", "reasoning_effort": True, "smol": "deepseek/v1"},
    "openai": {"label": "OpenAI", "base_url": "https://api.openai.com/v1", "key_env": "OPENAI_API_KEY",
               "model_env": "OPENAI_MODEL", "model": "gpt-5-mini", "reasoning_effort": True, "smol": "openai/v1"},
    "gemini": {"label": "Google Gemini", "base_url": "https://generativelanguage.googleapis.com/v1beta/openai/",
               "key_env": "GEMINI_API_KEY", "model_env": "GEMINI_MODEL", "model": "gemini-3.5-flash", "reasoning_effort": True,
               "smol": "google/v1beta"},
    "qwen": {"label": "Alibaba Qwen", "base_url": "https://dashscope-intl.aliyuncs.com/compatible-mode/v1",
             "base_env": "QWEN_BASE_URL", "key_env": "DASHSCOPE_API_KEY", "model_env": "QWEN_MODEL", "model": "qwen3.7-plus",
             "reasoning_effort": False, "smol": "alibaba/v1"},
    "kimi": {"label": "Moonshot Kimi", "base_url": "https://api.moonshot.ai/v1", "key_env": "MOONSHOT_API_KEY",
             "model_env": "KIMI_MODEL", "model": "kimi-k3", "reasoning_effort": False, "smol": "kimi/v1"},
    "glm": {"label": "Zhipu GLM", "base_url": "https://open.bigmodel.cn/api/paas/v4", "key_env": "ZHIPU_API_KEY",
            "model_env": "GLM_MODEL", "model": "glm-5.1", "reasoning_effort": False, "smol": "glm/v1"},
    "openrouter": {"label": "OpenRouter", "base_url": "https://openrouter.ai/api/v1", "key_env": "OPENROUTER_API_KEY",
                   "model_env": "OPENROUTER_MODEL", "model": "openai/gpt-4o-mini", "reasoning_effort": False},
}

# contestant id -> definition. kind "openai" = OpenAI-compatible chat completions; "anthropic" = Claude.
LLM_CONTESTANTS: Dict[str, Dict] = {
    "deepseek": {"label": "DeepSeek Flash", "provider": "deepseek", "color": "#7b4fd6",
                 "extra_body": {"thinking": {"type": "enabled"}}, "desc": "DeepSeek V4.1 Flash, thinking mode on"},
    "deepseek_fast": {"label": "DeepSeek Flash · no thinking", "provider": "deepseek", "color": "#9d86e0",
                      "extra_body": {"thinking": {"type": "disabled"}}, "no_effort": True,
                      "desc": "same model with thinking mode off: answers immediately"},
    "deepseek_pro": {"label": "DeepSeek Pro", "provider": "deepseek", "model": "deepseek-v4-pro", "color": "#b0359b",
                     "extra_body": {"thinking": {"type": "enabled"}}, "desc": "DeepSeek V4 Pro, the larger model"},
    "deepseek_blind": {"label": "DeepSeek · blind", "provider": "deepseek", "color": "#4f9d8a", "blind": True,
                       "extra_body": {"thinking": {"type": "enabled"}}, "desc": "reagents renamed A/B, no chemistry context"},
    "deepseek_permuted": {"label": "DeepSeek · scrambled", "provider": "deepseek", "color": "#c2384f", "permute": True,
                          "extra_body": {"thinking": {"type": "enabled"}}, "desc": "ablation: every result belongs to a random other recipe"},
    "gpt": {"label": "OpenAI GPT", "provider": "openai", "color": "#10a37f", "desc": "OpenAI chat model (OPENAI_MODEL)"},
    "gemini": {"label": "Google Gemini", "provider": "gemini", "color": "#4285f4", "desc": "Gemini via its OpenAI-compatible endpoint (GEMINI_MODEL)"},
    "qwen": {"label": "Alibaba Qwen", "provider": "qwen", "color": "#ff6a00", "desc": "Qwen via DashScope compatible mode (QWEN_MODEL)"},
    "kimi": {"label": "Moonshot Kimi", "provider": "kimi", "color": "#1f2937", "desc": "Kimi via Moonshot API (KIMI_MODEL)"},
    "glm": {"label": "Zhipu GLM", "provider": "glm", "color": "#3b5bdb", "desc": "GLM via Zhipu BigModel API (GLM_MODEL)"},
    "openrouter": {"label": "OpenRouter model", "provider": "openrouter", "color": "#6b7280", "desc": "any model on OpenRouter (OPENROUTER_MODEL)"},
    "llm": {"label": "Claude", "kind": "anthropic", "color": "#d4733a", "desc": "Claude (claude-opus-5-5) via the Anthropic API"},
}


SMOL_KEY_ENV = "SMOLPROXY_API_KEY"
SMOL_BASE = "https://smolproxy.org"


def resolve(provider: str):
    """(base_url, api_key, route) for a provider: its own key first, then the smolproxy relay."""
    cfg = PROVIDERS[provider]
    own = os.environ.get(cfg["key_env"])
    if own:
        base = (os.environ.get(cfg["base_env"]) if cfg.get("base_env") else None) or cfg["base_url"]
        return base, own, "direct"
    smol = os.environ.get(SMOL_KEY_ENV)
    if smol and cfg.get("smol"):
        return f"{os.environ.get('SMOLPROXY_BASE_URL', SMOL_BASE).rstrip('/')}/{cfg['smol']}", smol, "smolproxy"
    return cfg["base_url"], None, None


def is_llm(name: str) -> bool:
    return name in LLM_CONTESTANTS or ":" in name or name.startswith("llm")


def provider_of(name: str) -> Optional[str]:
    if ":" in name:
        return name.split(":", 1)[0]
    d = LLM_CONTESTANTS.get(name)
    return None if d is None or d.get("kind") == "anthropic" else d["provider"]


def model_of(name: str) -> Optional[str]:
    if ":" in name:
        return name.split(":", 1)[1]
    d = LLM_CONTESTANTS.get(name)
    if d is None:
        return None
    if d.get("kind") == "anthropic":
        return os.environ.get("RAISE_SIM_MODEL", "claude-opus-5-5")
    p = PROVIDERS[d["provider"]]
    return d.get("model") or os.environ.get(p["model_env"]) or p["model"]


def available(name: str) -> bool:
    if name.startswith("llm"):
        return bool(os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN"))
    prov = provider_of(name)
    return bool(prov and prov in PROVIDERS and resolve(prov)[1])


def label_of(name: str) -> str:
    if ":" in name:
        prov, model = name.split(":", 1)
        return f"{PROVIDERS.get(prov, {}).get('label', prov)} · {model}"
    d = LLM_CONTESTANTS.get(name)
    return d["label"] if d else name
