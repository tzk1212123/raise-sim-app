"""Claude as the experiment planner (manual tool-use loop).

The agent gets the task, bounds, budget and the shared initial results, then
calls `run_experiment` one formulation at a time and ends with
`finish_campaign(sds, tween, reasoning)`. A manual loop (rather than the SDK
tool runner) lets us enforce the experiment budget exactly, log token usage
per turn, and inject the ablations below.

Variants (constructor flags):
  blind=True             reagent names become "A"/"B", no chemistry context (T2)
  permute_labels=True    every returned measurement is the true measurement of a
                         *different, random* grid formulation. If performance does
                         not drop, the agent is not using feedback.

Requires `pip install anthropic` and credentials (ANTHROPIC_API_KEY or an
`ant auth login` profile). Server-side refusal fallback is enabled by default
(`fallbacks: "default"`); pass fallbacks=None to turn it off.
"""
from __future__ import annotations

import json
import os
import random
from typing import Any, Dict, List, Optional, Sequence

from .base import Planner, Point

DEFAULT_MODEL = os.environ.get("RAISE_SIM_MODEL", "claude-opus-5-5")

SYSTEM_TEMPLATE = """You are the autonomous experimentalist running a liquid-formulation campaign on a \
robotic contact-angle platform (OT-2 liquid handler + camera).

{chem}

Objective: find a formulation whose static contact angle matches {target:g} deg (acceptable window \
{w0:g}-{w1:g} deg) while using as little total surfactant as possible. The platform scores each \
measurement with desirability D = sqrt((1 - |angle - {target:g}|/50) * (1 - total/2.0)), total in % w/v.

Inputs (both required, % w/v, on a {step:g} grid): {a} in [{a0:g}, {a1:g}], {b} in [{b0:g}, {b1:g}].
Hard budget: {budget} experiments in total, of which {n_init} initial ones were already run for you.

Facts about the measurement:
- Each experiment prepares one mixture and images {droplets} droplets; you get their mean and SD.
- Replicate noise is roughly 0.5-1.5 deg, stage positions add small offsets, and occasional gross outliers occur.
- A detection failure returns angle = null. That is missing data, not a bad result. Do not treat it as a number.

Working rules:
- Call run_experiment once per step and read the result before choosing the next formulation.
  Before each call, state your hypothesis in one or two sentences.
- You may repeat a formulation if you need to confirm it.
- When the budget is used up, or you are confident further runs will not help, call \
finish_campaign with the single formulation you recommend. It will be re-tested in fresh replicates, \
so recommend the one you believe truly sits in the window with the least surfactant, not a lucky reading."""

CHEM = ("Reagent A is commercial-grade sodium dodecyl sulfate (SDS, 94 % purity, anionic). "
        "Reagent B is Tween 20 (polysorbate 20, nonionic). The substrate is fixed.")
BLIND = "Reagents A and B are two liquid additives. Nothing else is known about them."


def _safe(fn):
    """Logging must never kill a campaign (e.g. GBK consoles on Windows)."""
    def wrapped(msg):
        try:
            fn(msg)
        except UnicodeEncodeError:
            fn(msg.encode("ascii", "replace").decode("ascii"))
        except Exception:
            pass
    return wrapped


class LLMPlanner(Planner):
    name = "llm"

    def __init__(self, task, seed: int = 0, model: str = DEFAULT_MODEL, effort: str = "medium",
                 blind: bool = False, permute_labels: bool = False, client: Any = None,
                 fallbacks: Optional[str] = "default", max_turns: int = 400, log=print):
        super().__init__(task, seed)
        self.model, self.effort = model, effort
        self.blind, self.permute = blind, permute_labels
        self.fallbacks = fallbacks
        self.max_turns = max_turns
        self.log = _safe(log) if log else (lambda *_: None)
        self._client = client
        self.usage = {"input_tokens": 0, "output_tokens": 0, "turns": 0}
        self.final: Optional[Dict] = None
        self.transcript_text: List[str] = []
        self.thought_log: List[Dict] = []   # one entry per model turn: what it thought and decided
        if blind:
            self.name = "llm_blind"
        if permute_labels:
            self.name += "_permuted"
        self._perm_rng = random.Random(777 + seed)

    def _log_thought(self, tests_done: int, text: Optional[str], reasoning: Optional[str], calls) -> None:
        """Record one model turn for the UI: prose, reasoning (if the API exposes it) and the action."""
        a, b = self._names()
        actions = []
        for name, args in calls:
            try:
                d = args if isinstance(args, dict) else json.loads(args or "{}")
            except Exception:
                d = {}
            if name == "run_experiment":
                actions.append(f"test {tests_done + len(actions) + 1}: {a}={d.get(a)} / {b}={d.get(b)}")
            elif name == "finish_campaign":
                actions.append(f"final answer: {a}={d.get(a)} / {b}={d.get(b)}")
        self.thought_log.append({"turn": len(self.thought_log) + 1, "tests_done": tests_done,
                                 "text": (text or "").strip()[:3000], "reasoning": (reasoning or "").strip()[:6000],
                                 "actions": actions})

    # Planner interface: the LLM drives its own loop, so `suggest` is unused.
    def suggest(self, history: Sequence[Dict]) -> Point:
        raise NotImplementedError("LLMPlanner runs its own loop: use run_agent()")

    @property
    def client(self):
        if self._client is None:
            import anthropic
            self._client = anthropic.Anthropic()
        return self._client

    def _names(self):
        return ("A", "B") if self.blind else ("sds", "tween")

    def _tools(self) -> List[Dict]:
        a, b = self._names()
        t = self.task
        num = lambda lo, hi, desc: {"type": "number", "minimum": lo, "maximum": hi, "description": desc}
        return [
            {"name": "run_experiment", "strict": True,
             "description": "Prepare one formulation, image its droplets and return the measured result as JSON.",
             "input_schema": {"type": "object", "additionalProperties": False, "required": [a, b],
                              "properties": {a: num(t.sds_range[0], t.sds_range[1], f"{a} in % w/v"),
                                             b: num(t.tween_range[0], t.tween_range[1], f"{b} in % w/v")}}},
            {"name": "finish_campaign", "strict": True,
             "description": "End the campaign and recommend one formulation for validation.",
             "input_schema": {"type": "object", "additionalProperties": False, "required": [a, b, "reasoning"],
                              "properties": {a: num(t.sds_range[0], t.sds_range[1], f"recommended {a}"),
                                             b: num(t.tween_range[0], t.tween_range[1], f"recommended {b}"),
                                             "reasoning": {"type": "string"}}}},
        ]

    def _public(self, rec: Dict) -> Dict:
        a, b = self._names()
        out = {"run": rec["run_id"], a: rec["set"]["sds_wv_pct"], b: rec["set"]["tween_wv_pct"],
               "status": rec["status"], "angle_mean": rec.get("contact_angle_mean"),
               "angle_sd": rec.get("contact_angle_sd"), "n_valid": rec.get("n_valid"),
               "droplet_angles": [d["angle_deg"] for d in rec.get("droplets", [])],
               "total": rec.get("total_wv_pct"), "desirability": rec.get("desirability")}
        if rec.get("error"):
            out["error"] = rec["error"]
        return out

    def _snap(self, v: float, lo: float) -> float:
        step = self.task.step
        return round(lo + round((v - lo) / step) * step, 4)

    def _execute(self, exp, a_val: float, b_val: float) -> Dict:
        s = self._snap(a_val, self.task.sds_range[0])
        t = self._snap(b_val, self.task.tween_range[0])
        rec = exp.run(s, t, tag=self.name)
        if self.permute and rec.get("contact_angle_mean") is not None:
            # replace the outcome with the real outcome of a different random formulation
            # measured on a separate shadow rig so the ablation does not consume the
            # real rig's time or consumables
            if getattr(self, "_shadow", None) is None:
                from dataclasses import replace
                from ..experiment import Experiment
                self._shadow = Experiment(exp.lab.surface, replace(exp.cfg, seed=(exp.cfg.seed or 0) + 1, data_dir=None))
            ps, pt = self._perm_rng.choice(self.grid)
            shadow = self._shadow.protocol.run(ps, pt)
            shadow.pop("_truth", None)
            rec = dict(rec)
            for k in ("contact_angle_mean", "contact_angle_sd", "n_valid", "droplets", "status"):
                rec[k] = shadow[k]
            rec["desirability"] = (None if rec["contact_angle_mean"] is None else
                                   round(self.task.desirability(rec["contact_angle_mean"], s, t), 4))
        return rec

    def run_agent(self, exp, budget: int, init_history: List[Dict]) -> Dict:
        t = self.task
        a, b = self._names()
        system = SYSTEM_TEMPLATE.format(
            chem=BLIND if self.blind else CHEM, target=t.target_deg, w0=t.window[0], w1=t.window[1],
            step=t.step, a=a, b=b, a0=t.sds_range[0], a1=t.sds_range[1], b0=t.tween_range[0],
            b1=t.tween_range[1], budget=budget, n_init=len(init_history), droplets=exp.cfg.droplets)
        history = list(init_history)
        first = ("Initial results:\n" + "\n".join(json.dumps(self._public(r)) for r in history) +
                 f"\n\nYou have {budget - len(history)} experiments left. Plan the campaign, then begin.")
        messages: List[Dict] = [{"role": "user", "content": first}]
        tools = self._tools()
        for turn in range(self.max_turns):
            # top-level auto-caching: the growing, append-only history is re-sent every turn
            kwargs = dict(model=self.model, max_tokens=16000, system=system, tools=tools,
                          messages=messages, output_config={"effort": self.effort},
                          thinking={"type": "adaptive", "display": "summarized"},
                          cache_control={"type": "ephemeral"})
            if self.fallbacks:
                resp = self.client.beta.messages.create(betas=["server-side-fallback-2026-07-01"],
                                                        fallbacks=self.fallbacks, **kwargs)
            else:
                resp = self.client.messages.create(**kwargs)
            self.usage["turns"] += 1
            u = getattr(resp, "usage", None)
            if u is not None:
                for k in ("input_tokens", "output_tokens", "cache_read_input_tokens", "cache_creation_input_tokens"):
                    self.usage[k] = self.usage.get(k, 0) + (getattr(u, k, 0) or 0)
            for blk in resp.content:
                if getattr(blk, "type", "") == "text" and blk.text.strip():
                    self.transcript_text.append(blk.text)
                    self.log(f"[{self.name}] {blk.text.strip()[:300]}")
            self._log_thought(
                len(history),
                "\n".join(blk.text for blk in resp.content if getattr(blk, "type", "") == "text"),
                "\n".join(getattr(blk, "thinking", "") or "" for blk in resp.content if getattr(blk, "type", "") == "thinking"),
                [(blk.name, blk.input) for blk in resp.content if getattr(blk, "type", "") == "tool_use"])
            if resp.stop_reason == "refusal":
                self.final = {"stopped": "refusal"}
                break
            messages.append({"role": "assistant", "content": resp.content})
            if resp.stop_reason == "pause_turn":
                continue
            calls = [blk for blk in resp.content if getattr(blk, "type", "") == "tool_use"]
            if not calls:
                if len(history) >= budget:
                    break
                messages.append({"role": "user", "content":
                                 f"{budget - len(history)} experiments remain. Continue with run_experiment, "
                                 "or call finish_campaign."})
                continue
            results, done = [], False
            for call in calls:
                inp = call.input if isinstance(call.input, dict) else json.loads(call.input)
                if call.name == "finish_campaign":
                    self.final = {"sds": self._snap(float(inp[a]), t.sds_range[0]),
                                  "tween": self._snap(float(inp[b]), t.tween_range[0]),
                                  "reasoning": inp.get("reasoning", "")}
                    results.append({"type": "tool_result", "tool_use_id": call.id, "content": "Campaign closed."})
                    done = True
                elif call.name == "run_experiment":
                    if len(history) >= budget:
                        results.append({"type": "tool_result", "tool_use_id": call.id, "is_error": True,
                                        "content": "Budget exhausted. Call finish_campaign now."})
                        continue
                    rec = self._execute(exp, float(inp[a]), float(inp[b]))
                    history.append(rec)
                    pub = self._public(rec)
                    pub["experiments_left"] = budget - len(history)
                    results.append({"type": "tool_result", "tool_use_id": call.id, "content": json.dumps(pub)})
                else:
                    results.append({"type": "tool_result", "tool_use_id": call.id, "is_error": True,
                                    "content": f"unknown tool {call.name}"})
            messages.append({"role": "user", "content": results})
            if done:
                break
        rec = (self.final["sds"], self.final["tween"]) if self.final and "sds" in self.final else \
            Planner.recommend(self, history)
        return {"history": history, "recommendation": rec}

    def notes(self) -> Dict:
        return {"model": self.model, "effort": self.effort, "usage": self.usage,
                "final": self.final, "blind": self.blind, "permute_labels": self.permute}
