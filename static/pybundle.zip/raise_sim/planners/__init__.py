from .base import Planner, run_campaign, initial_design, observations
from .baselines import RandomPlanner, OFATPlanner
from .bo import BODesirability, BOAngle

PLANNERS = {
    "random": RandomPlanner,
    "ofat": OFATPlanner,
    "bo_ts": BODesirability,
    "bo_angle": BOAngle,
}


def make_planner(name: str, task, seed: int = 0, **kw):
    if name.startswith("llm"):
        from .llm import LLMPlanner
        return LLMPlanner(task, seed=seed, blind="blind" in name, permute_labels="permuted" in name, **kw)
    from .registry import LLM_CONTESTANTS, PROVIDERS as _PROV
    if ":" in name or (name in LLM_CONTESTANTS and LLM_CONTESTANTS[name].get("kind") != "anthropic"):
        from .openai_compat import OpenAICompatPlanner
        if ":" in name:
            prov, model = name.split(":", 1)
            if prov not in _PROV:
                raise ValueError(f"unknown provider {prov!r} (known: {sorted(_PROV)})")
            d = {"provider": prov, "model": model}
        else:
            d = LLM_CONTESTANTS[name]
        if d.get("model"):
            kw.setdefault("model", d["model"])
        p = OpenAICompatPlanner(task, seed=seed, provider=d["provider"], blind=d.get("blind", False),
                                permute_labels=d.get("permute", False), extra_body=d.get("extra_body"),
                                no_effort=d.get("no_effort", False), **kw)
        p.name = name
        return p
    return PLANNERS[name](task, seed=seed, **kw)


__all__ = ["Planner", "run_campaign", "initial_design", "observations", "RandomPlanner",
           "OFATPlanner", "BODesirability", "BOAngle", "PLANNERS", "make_planner"]
