"""LLM planner over an OpenAI-compatible Chat Completions API (default: DeepSeek).

Same task prompt, tools, budget enforcement, blind / permuted-label variants and
recommendation contract as `llm.LLMPlanner`; only the wire format differs.

DeepSeek specifics (api-docs.deepseek.com, checked 2026-11-04):
  * base_url https://api.deepseek.com, models `deepseek-flash` (V4.1 Flash) and `deepseek-v4-pro`;
  * thinking mode on by default; enable explicitly via extra_body={"thinking": {"type": "enabled"}}
    and `reasoning_effort` (low | high | max);
  * with `tools` in the request, every assistant turn's `reasoning_content` must be passed back
    unchanged in all later requests, otherwise the API returns 400;
  * strict tool schemas need the /beta base URL, so arguments are validated client-side here.

Credentials: DEEPSEEK_API_KEY (or pass api_key / client).
"""
from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional

from .base import Planner
from .llm import BLIND, CHEM, SYSTEM_TEMPLATE, LLMPlanner
from .registry import PROVIDERS, resolve


def _tool_call_dict(c) -> Dict[str, Any]:
    """Assistant tool call as a plain dict, keeping any provider-specific extra fields."""
    d: Dict[str, Any] = {"id": c.id, "type": "function",
                         "function": {"name": c.function.name, "arguments": c.function.arguments}}
    dump = getattr(c, "model_dump", None)
    if callable(dump):
        try:
            full = dump(exclude_none=True)
        except Exception:
            full = {}
        if isinstance(full, dict):
            for k, v in full.items():
                if k not in d:
                    d[k] = v
    return d


class OpenAICompatPlanner(LLMPlanner):
    name = "deepseek"

    def __init__(self, task, seed: int = 0, provider: str = "deepseek", model: Optional[str] = None,
                 effort: str = "high", base_url: Optional[str] = None, api_key: Optional[str] = None,
                 extra_body: Optional[Dict] = None, client: Any = None, blind: bool = False,
                 permute_labels: bool = False, max_turns: int = 400, log=print, no_effort: bool = False):
        cfg = PROVIDERS[provider]
        model = model or os.environ.get(cfg["model_env"]) or cfg["model"]
        super().__init__(task, seed=seed, model=model, effort=effort, blind=blind,
                         permute_labels=permute_labels, client=client, fallbacks=None,
                         max_turns=max_turns, log=log)
        self.provider = provider
        r_base, r_key, self.route = resolve(provider)   # own key first, else the smolproxy relay
        self.base_url = base_url or r_base
        self.api_key = api_key or r_key
        self.key_env = cfg["key_env"]
        self.extra_body = extra_body
        self.use_effort = cfg.get("reasoning_effort", False) and not no_effort
        self.name = provider + ("_blind" if blind else "") + ("_permuted" if permute_labels else "")

    @property
    def client(self):
        if self._client is None:
            from openai import OpenAI
            if not self.api_key:
                raise RuntimeError(f"set {self.key_env} (or SMOLPROXY_API_KEY) to use the {self.provider} planner")
            self._client = OpenAI(api_key=self.api_key, base_url=self.base_url)
        return self._client

    def _oa_tools(self) -> List[Dict]:
        return [{"type": "function", "function": {"name": t["name"], "description": t["description"],
                                                  "parameters": t["input_schema"]}} for t in self._tools()]

    def _validate(self, name: str, args: Dict) -> Optional[str]:
        schema = next(t["input_schema"] for t in self._tools() if t["name"] == name)
        for k in schema["required"]:
            if k not in args:
                return f"missing argument {k!r}"
        for k, spec in schema["properties"].items():
            if spec.get("type") == "number":
                try:
                    v = float(args[k])
                except (TypeError, ValueError):
                    return f"{k} must be a number"
                if not (spec["minimum"] - 1e-9 <= v <= spec["maximum"] + 1e-9):
                    return f"{k}={v:g} outside [{spec['minimum']:g}, {spec['maximum']:g}]"
        return None

    def run_agent(self, exp, budget: int, init_history: List[Dict]) -> Dict:
        t = self.task
        a, b = self._names()
        system = SYSTEM_TEMPLATE.format(
            chem=BLIND if self.blind else CHEM, target=t.target_deg, w0=t.window[0], w1=t.window[1],
            step=t.step, a=a, b=b, a0=t.sds_range[0], a1=t.sds_range[1], b0=t.tween_range[0],
            b1=t.tween_range[1], budget=budget, n_init=len(init_history), droplets=exp.cfg.droplets)
        history = list(init_history)
        first = ("Initial results:\n" + "\n".join(json.dumps(self._public(r)) for r in history) +
                 f"\n\nYou have {budget - len(history)} experiments left. Plan the campaign, then begin.")
        messages: List[Dict] = [{"role": "system", "content": system}, {"role": "user", "content": first}]
        tools = self._oa_tools()
        for _ in range(self.max_turns):
            req: Dict[str, Any] = dict(model=self.model, messages=messages, tools=tools)
            if self.use_effort:
                req["reasoning_effort"] = self.effort
            if self.extra_body:
                req["extra_body"] = self.extra_body
            resp = self.client.chat.completions.create(**req)
            self.usage["turns"] += 1
            u = getattr(resp, "usage", None)
            if u is not None:
                self.usage["input_tokens"] += getattr(u, "prompt_tokens", 0) or 0
                self.usage["output_tokens"] += getattr(u, "completion_tokens", 0) or 0
                hit = getattr(u, "prompt_cache_hit_tokens", None)
                if hit is not None:
                    self.usage["cache_read_input_tokens"] = self.usage.get("cache_read_input_tokens", 0) + hit
            msg = resp.choices[0].message
            rc_text = getattr(msg, "reasoning_content", None)
            if msg.content and msg.content.strip():
                self.transcript_text.append(msg.content)
                self.log(f"[{self.name}] {msg.content.strip()[:300]}")
            elif rc_text and rc_text.strip():   # model wrote no prose: show the tail of its reasoning
                self.transcript_text.append("(thinking) …" + rc_text.strip()[-500:])
            calls = list(msg.tool_calls or [])
            self._log_thought(len(history), msg.content, rc_text,
                              [(c.function.name, c.function.arguments) for c in calls])
            # pass the assistant turn back verbatim, including reasoning_content (required with tools)
            am: Dict[str, Any] = {"role": "assistant", "content": msg.content or ""}
            rc = getattr(msg, "reasoning_content", None)
            if rc is not None:
                am["reasoning_content"] = rc
            if calls:
                # keep provider extras verbatim (Gemini 3 needs extra_content.google.thought_signature)
                am["tool_calls"] = [_tool_call_dict(c) for c in calls]
            messages.append(am)
            if not calls:
                if len(history) >= budget:
                    break
                messages.append({"role": "user", "content": f"{budget - len(history)} experiments remain. "
                                 "Continue with run_experiment, or call finish_campaign."})
                continue
            done = False
            for c in calls:
                try:
                    args = json.loads(c.function.arguments or "{}")
                except json.JSONDecodeError:
                    args, err = {}, "arguments were not valid JSON"
                else:
                    err = self._validate(c.function.name, args) if c.function.name in ("run_experiment", "finish_campaign") \
                        else f"unknown tool {c.function.name}"
                if err:
                    out = json.dumps({"error": err})
                elif c.function.name == "finish_campaign":
                    self.final = {"sds": self._snap(float(args[a]), t.sds_range[0]),
                                  "tween": self._snap(float(args[b]), t.tween_range[0]),
                                  "reasoning": args.get("reasoning", "")}
                    out, done = "Campaign closed.", True
                elif len(history) >= budget:
                    out = json.dumps({"error": "Budget exhausted. Call finish_campaign now."})
                else:
                    rec = self._execute(exp, float(args[a]), float(args[b]))
                    history.append(rec)
                    pub = self._public(rec)
                    pub["experiments_left"] = budget - len(history)
                    out = json.dumps(pub)
                messages.append({"role": "tool", "tool_call_id": c.id, "content": out})
            if done:
                break
        rec = (self.final["sds"], self.final["tween"]) if self.final and "sds" in self.final else \
            Planner.recommend(self, history)
        return {"history": history, "recommendation": rec}

    def notes(self) -> Dict:
        n = super().notes()
        n.update({"provider": self.provider, "base_url": self.base_url})
        n.pop("fallbacks", None)
        return n
