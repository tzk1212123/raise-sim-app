"""Bayesian optimisation planners (numpy/scikit-learn only, fully offline).

* BODesirability ("bo_ts"): RAISE-like. GP on the scalar desirability with
  Thompson sampling over the untried grid (RAISE used BayBE: GP + Thompson
  sampling, first point random).
* BOAngle ("bo_angle"): GP on the contact angle itself; the known, exact
  total-surfactant term is applied analytically to each Thompson draw. Uses the
  problem structure a careful practitioner would exploit.

Both recommend the measured formulation with the best posterior-mean
desirability (denoised), preferring points whose posterior-mean angle is in
the target window.
"""
from __future__ import annotations

import warnings
from typing import Dict, List, Optional, Sequence

import numpy as np
from sklearn.exceptions import ConvergenceWarning
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel, Matern, WhiteKernel

from .base import Planner, Point, observations


class _GPPlanner(Planner):
    target = "desirability"

    def __init__(self, task, seed: int = 0, n_candidates: Optional[int] = None):
        super().__init__(task, seed)
        s = np.array(self.grid)
        self.lo, self.hi = s.min(0), s.max(0)
        self.np_rng = np.random.default_rng(seed)

    def _X(self, pts) -> np.ndarray:
        return (np.asarray(pts, float) - self.lo) / (self.hi - self.lo)

    def _fit(self, history):
        obs = observations(history)
        if len(obs) < 2:
            return None, obs
        X = self._X([(o.sds, o.tween) for o in obs])
        y = np.array([o.desirability if self.target == "desirability" else o.angle for o in obs])
        k = ConstantKernel(1.0, (1e-3, 1e3)) * Matern([0.3, 0.3], (0.02, 5.0), nu=2.5) \
            + WhiteKernel(1e-2, (1e-6, 1.0))
        gp = GaussianProcessRegressor(k, normalize_y=True, n_restarts_optimizer=2,
                                      random_state=int(self.np_rng.integers(1 << 30)))
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", ConvergenceWarning)
            gp.fit(X, y)
        return gp, obs

    def _score_draw(self, draw: np.ndarray, pts: List[Point]) -> np.ndarray:
        if self.target == "desirability":
            return draw
        return np.array([self.task.desirability(th, s, t) for th, (s, t) in zip(draw, pts)])

    def suggest(self, history: Sequence[Dict]) -> Point:
        gp, _ = self._fit(history)
        cand = self.untried(history) or self.grid
        if gp is None:
            return self.rng.choice(cand)
        draw = gp.sample_y(self._X(cand), random_state=int(self.np_rng.integers(1 << 30))).ravel()
        return cand[int(np.argmax(self._score_draw(draw, cand)))]

    def recommend(self, history: Sequence[Dict]) -> Optional[Point]:
        gp, obs = self._fit(history)
        if gp is None:
            return super().recommend(history)
        pts = sorted({(o.sds, o.tween) for o in obs})
        mu = gp.predict(self._X(pts))
        if self.target == "desirability":
            # RAISE-style window mask on the observed mean angle at each measured point
            score = mu
            ang = {}
            for o in obs:
                ang.setdefault((o.sds, o.tween), []).append(o.angle)
            inside = np.array([self.task.window[0] <= np.mean(ang[p]) <= self.task.window[1] for p in pts])
        else:
            score = np.array([self.task.desirability(th, s, t) for th, (s, t) in zip(mu, pts)])
            inside = (mu >= self.task.window[0]) & (mu <= self.task.window[1])
        idx = np.where(inside)[0] if inside.any() else np.arange(len(pts))
        return pts[int(idx[np.argmax(score[idx])])]


class BODesirability(_GPPlanner):
    name = "bo_ts"
    target = "desirability"


class BOAngle(_GPPlanner):
    name = "bo_angle"
    target = "angle"
