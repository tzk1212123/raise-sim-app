"""Planner interface and the shared campaign loop.

Fairness rules enforced here (same for every planner):
  * same task, bounds, grid and budget;
  * the same `n_init` random initial formulations for a given campaign seed;
  * planners see only public records (no ground truth);
  * failed / rejected runs count against the budget but carry no objective value.
"""
from __future__ import annotations

import random
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from ..task import Task

Point = Tuple[float, float]


@dataclass
class Obs:
    sds: float
    tween: float
    angle: float
    sd: Optional[float]
    n_valid: int
    desirability: float


def observations(history: Sequence[Dict]) -> List[Obs]:
    out = []
    for r in history:
        if r.get("contact_angle_mean") is None:
            continue
        out.append(Obs(r["set"]["sds_wv_pct"], r["set"]["tween_wv_pct"], r["contact_angle_mean"],
                       r.get("contact_angle_sd"), r["n_valid"], r["desirability"]))
    return out


def tried(history: Sequence[Dict]) -> set:
    return {(r["set"]["sds_wv_pct"], r["set"]["tween_wv_pct"]) for r in history}


class Planner(ABC):
    name = "base"

    def __init__(self, task: Task, seed: int = 0):
        self.task, self.seed = task, seed
        self.rng = random.Random(seed)
        self.grid: List[Point] = task.grid()

    def untried(self, history) -> List[Point]:
        t = tried(history)
        return [p for p in self.grid if p not in t]

    @abstractmethod
    def suggest(self, history: Sequence[Dict]) -> Point: ...

    def recommend(self, history: Sequence[Dict]) -> Optional[Point]:
        """Default: best observed mean desirability among runs with >= 2 valid droplets
        that sit inside the target window; falls back to best desirability overall."""
        obs = [o for o in observations(history) if o.n_valid >= 2] or observations(history)
        if not obs:
            return None
        inside = [o for o in obs if self.task.window[0] <= o.angle <= self.task.window[1]]
        best = max(inside or obs, key=lambda o: o.desirability)
        return best.sds, best.tween

    def notes(self) -> Dict:
        return {}


def initial_design(task: Task, n_init: int, seed: int) -> List[Point]:
    rng = random.Random(10_000 + seed)
    return rng.sample(task.grid(), n_init)


def run_campaign(exp, planner: Planner, budget: int, n_init: int = 3, seed: int = 0,
                 on_step=None) -> Dict:
    """Run `budget` experiments (including the shared initial design)."""
    history: List[Dict] = []
    for p in initial_design(planner.task, min(n_init, budget), seed):
        history.append(exp.run(*p, tag=f"{planner.name}:init"))
        if on_step:
            on_step(history[-1])
    if hasattr(planner, "run_agent"):   # LLM planners own their loop
        out = planner.run_agent(exp, budget, history)
        return {"planner": planner.name, "budget": budget, "n_init": n_init, "seed": seed,
                "history": out["history"], "recommendation": out["recommendation"], "notes": planner.notes()}
    while len(history) < budget:
        s, t = planner.suggest(history)
        history.append(exp.run(s, t, tag=planner.name))
        if on_step:
            on_step(history[-1])
    rec = planner.recommend(history)
    return {"planner": planner.name, "budget": budget, "n_init": n_init, "seed": seed,
            "history": history, "recommendation": rec, "notes": planner.notes()}
