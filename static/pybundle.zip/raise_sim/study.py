"""Repeated comparison study: run every contestant many times and aggregate.

Each repeat r uses one seed s_r shared by all contestants (same simulated world
draw, same random starters, same measurement noise sequence), so differences
between contestants within a repeat come from their decisions only (paired
design). Repeats differ in seed and, optionally, in which plausible world
(surface family member) is used.

Per-campaign metrics come from benchmark._job / evaluate:
  success          final answer's TRUE angle inside 70.39-73.61 deg
  score            100 * true desirability of the answer if success else 0
  found_good       some test measured on target with score >= 90 (observed)
  tests_to_good    index of that first test (observed), None if never
  tests_used       experiments consumed (LLMs may stop early)
  robot_min        simulated robot time
  wall_s           real elapsed time of the campaign (LLM latency included)
  tokens / cost    LLM usage and an upper-bound cost at DeepSeek peak list prices
"""
from __future__ import annotations

import json
import math
import random
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from statistics import mean, median
from typing import Any, Dict, List, Optional

from .benchmark import _job, summarise

WINDOW = (70.39, 73.61)
GOOD = 0.90
# USD per 1M tokens at DeepSeek PEAK list prices (api-docs.deepseek.com, 2026-11-04): an upper bound
PRICES = {"deepseek-flash": (0.006, 0.30, 1.20), "deepseek-v4-pro": (0.044, 1.32, 3.96)}
WORLDS = {"physics": [("physics", 0)],
          "mixed": [("physics", 0), ("family", 1), ("family", 2), ("family", 3), ("gp", 0)]}


def _cost(notes: Dict) -> Optional[float]:
    u, model = (notes or {}).get("usage"), (notes or {}).get("model")
    if not u or model not in PRICES:
        return None
    hit, miss, out = PRICES[model]
    cached = u.get("cache_read_input_tokens", 0) or 0
    return (cached * hit + max(0, u.get("input_tokens", 0) - cached) * miss + u.get("output_tokens", 0) * out) / 1e6


def _flat(m: Dict, trace: List[Dict], repeat: int) -> Dict:
    first = next((t["i"] for t in trace if t["angle"] is not None and WINDOW[0] <= t["angle"] <= WINDOW[1]
                  and (t["D"] or 0) >= GOOD), None)
    notes = m.get("notes") or {}
    u = notes.get("usage") if isinstance(notes, dict) else None
    ok = bool(m.get("true_in_window"))
    return {"repeat": repeat, "planner": m["planner"], "seed": m["seed"], "world": m.get("surface"),
            "answer_sds": (m.get("rec") or [None, None])[0], "answer_tween": (m.get("rec") or [None, None])[1],
            "true_angle": m.get("true_theta"), "success": ok, "score": round(100 * m["true_D"], 1) if ok else 0.0,
            "retest_angle": m.get("val_angle_mean"), "found_good": first is not None, "tests_to_good": first,
            "tests_used": len(trace), "robot_min": m.get("sim_minutes"), "wall_s": m.get("wall_s"),
            "tokens_in": (u or {}).get("input_tokens"), "tokens_out": (u or {}).get("output_tokens"),
            "cost_usd": _cost(notes if isinstance(notes, dict) else {}), "regret": m.get("regret")}


def _mean_se(xs):
    xs = [x for x in xs if x is not None]
    if not xs:
        return None, None
    if len(xs) == 1:
        return float(xs[0]), None
    mu = mean(xs)
    sd = math.sqrt(sum((x - mu) ** 2 for x in xs) / (len(xs) - 1))
    return mu, sd / math.sqrt(len(xs))


def _wilson(k: int, n: int, z: float = 1.96):
    if n == 0:
        return None, None, None
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return p, max(0.0, c - h), min(1.0, c + h)


def aggregate(rows: List[Dict]) -> List[Dict]:
    out = []
    for p in sorted({r["planner"] for r in rows}, key=lambda x: [r["planner"] for r in rows].index(x)):
        g = [r for r in rows if r["planner"] == p]
        n = len(g)
        ks = sum(r["success"] for r in g)
        sr, lo, hi = _wilson(ks, n)
        kf = sum(r["found_good"] for r in g)
        fr, flo, fhi = _wilson(kf, n)
        sc, sc_se = _mean_se([r["score"] for r in g])
        ttg = [r["tests_to_good"] for r in g if r["tests_to_good"] is not None]
        tu, tu_se = _mean_se([r["tests_used"] for r in g])
        rm, rm_se = _mean_se([r["robot_min"] for r in g])
        ws, ws_se = _mean_se([r["wall_s"] for r in g])
        costs = [r["cost_usd"] for r in g if r["cost_usd"] is not None]
        tin = [r["tokens_in"] for r in g if r["tokens_in"] is not None]
        tout = [r["tokens_out"] for r in g if r["tokens_out"] is not None]
        out.append({"planner": p, "n": n,
                    "success_rate": sr, "success_lo": lo, "success_hi": hi, "successes": ks,
                    "score_mean": sc, "score_se": sc_se,
                    "found_rate": fr, "found_lo": flo, "found_hi": fhi,
                    "tests_to_good_mean": mean(ttg) if ttg else None, "tests_to_good_median": median(ttg) if ttg else None,
                    "tests_to_good_se": _mean_se(ttg)[1] if ttg else None, "tests_to_good_values": [r["tests_to_good"] for r in g],
                    "tests_used_mean": tu, "tests_used_se": tu_se,
                    "robot_min_mean": rm, "robot_min_se": rm_se,
                    "wall_s_mean": ws, "wall_s_se": ws_se,
                    "tokens_in_mean": mean(tin) if tin else None, "tokens_out_mean": mean(tout) if tout else None,
                    "cost_total_usd": sum(costs) if costs else None, "cost_per_run_usd": mean(costs) if costs else None})
    return out


class Study:
    def __init__(self, root: Path):
        self.root = root
        self.lock = threading.Lock()
        self.state: Dict[str, Any] = {"state": "idle"}
        self.rows: List[Dict] = []
        self.raw: List[Dict] = []
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def start(self, planners: List[str], repeats: int, budget: int, n_init: int, worlds: str,
              base_seed: Optional[int], n_val: int = 5, workers: int = 4):
        if self.running():
            raise RuntimeError("a study is already running")
        base = random.randint(1, 10 ** 6) if base_seed is None else int(base_seed)
        wl = WORLDS[worlds]
        jobs = []
        for r in range(repeats):
            kind, idx = wl[r % len(wl)]
            for p in planners:
                jobs.append((r, (p, kind, idx, budget, base + r, n_init, n_val, {"noise_scale": 1.0}, {"log": None})))
        self.rows, self.raw = [], []
        self._stop.clear()
        self.state = {"state": "running", "planners": planners, "repeats": repeats, "budget": budget, "n_init": n_init,
                      "worlds": worlds, "base_seed": base, "total": len(jobs), "done": 0, "errors": [],
                      "started": time.time(), "saved_to": None}

        def work():
            with ThreadPoolExecutor(max_workers=workers) as ex:
                futs = {}
                for r, args in jobs:
                    futs[ex.submit(self._run_one, r, args)] = (r, args[0])
                for f in as_completed(futs):
                    r, p = futs[f]
                    try:
                        row, raw = f.result()
                        if row is not None:
                            with self.lock:
                                self.rows.append(row)
                                self.raw.append(raw)
                    except Exception as e:
                        self.state["errors"].append(f"{p} repeat {r + 1}: {type(e).__name__}: {e}")
                    self.state["done"] += 1
            self.state["state"] = "stopped" if self._stop.is_set() else "done"
            self.state["elapsed_s"] = round(time.time() - self.state["started"], 1)
            self._save()

        self._thread = threading.Thread(target=work, daemon=True)
        self._thread.start()

    def _run_one(self, r, args):
        if self._stop.is_set():
            return None, None
        m, trace = _job(args)
        return _flat(m, trace, r + 1), m

    def stop(self):
        self._stop.set()

    def _save(self):
        if not self.rows:
            return
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        out = self.root / "reports" / f"benchmark_web_{stamp}"
        out.mkdir(parents=True, exist_ok=True)
        meta = {k: v for k, v in self.state.items() if k not in ("errors",)}
        (out / "study.json").write_text(json.dumps({"meta": meta, "aggregate": aggregate(self.rows), "runs": self.rows},
                                                   indent=1, default=str), encoding="utf-8")
        (out / "summary.json").write_text(json.dumps(summarise(self.raw), indent=1, default=str), encoding="utf-8")
        (out / "runs.csv").write_text(self.csv(), encoding="utf-8")
        self.state["saved_to"] = str(out.relative_to(self.root))

    def csv(self) -> str:
        cols = ["repeat", "planner", "seed", "world", "answer_sds", "answer_tween", "true_angle", "success", "score",
                "retest_angle", "found_good", "tests_to_good", "tests_used", "robot_min", "wall_s", "tokens_in",
                "tokens_out", "cost_usd", "regret"]
        lines = [",".join(cols)]
        for r in sorted(self.rows, key=lambda x: (x["repeat"], x["planner"])):
            lines.append(",".join("" if r.get(c) is None else str(r.get(c)) for c in cols))
        return "\n".join(lines) + "\n"

    def view(self) -> Dict:
        with self.lock:
            rows = list(self.rows)
        return {"meta": self.state, "aggregate": aggregate(rows) if rows else [], "runs": rows}
