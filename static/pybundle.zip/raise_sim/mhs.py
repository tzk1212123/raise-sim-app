"""Minimal device layer in the spirit of the Model Hardware Standard (MHS).

Every instrument is a named device made of channels you read() or write(),
with a natural-language manifest and a device-level safety envelope that
rejects out-of-range writes no matter who asks (script, human, or agent).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple


class SafetyLimitError(RuntimeError):
    """A write was rejected by the device's declared envelope."""


class DeviceError(RuntimeError):
    """A device-level fault (depleted resource, driver failure, ...)."""


@dataclass
class Channel:
    name: str
    mode: str                      # "read" | "write" | "readwrite" | "action"
    unit: str = ""
    description: str = ""
    limits: Optional[Tuple[float, float]] = None
    read_fn: Optional[Callable[[], Any]] = None
    write_fn: Optional[Callable[[Any], Any]] = None

    def spec(self) -> Dict:
        d = {"name": self.name, "mode": self.mode, "unit": self.unit, "description": self.description}
        if self.limits:
            d["limits"] = {"min": self.limits[0], "max": self.limits[1]}
        return d


class Device:
    def __init__(self, name: str, device_class: str, description: str,
                 tags: Optional[List[str]] = None, channels: Optional[List[Channel]] = None):
        self.name, self.device_class, self.description = name, device_class, description
        self.tags = list(tags or [])
        self.channels: Dict[str, Channel] = {c.name: c for c in (channels or [])}

    def _ch(self, name: str) -> Channel:
        if name not in self.channels:
            raise KeyError(f"device {self.name!r} has no channel {name!r} (has {sorted(self.channels)})")
        return self.channels[name]

    def read(self, channel: str) -> Any:
        ch = self._ch(channel)
        if "read" not in ch.mode or ch.read_fn is None:
            raise SafetyLimitError(f"{self.name}.{channel} is not readable")
        return ch.read_fn()

    def write(self, channel: str, value: Any = None) -> Any:
        ch = self._ch(channel)
        if ch.mode not in ("write", "readwrite", "action") or ch.write_fn is None:
            raise SafetyLimitError(f"{self.name}.{channel} is not writable")
        if ch.limits is not None:
            vals = value.get("volume_uL") if isinstance(value, dict) else value
            vals = vals if isinstance(vals, (list, tuple)) else [vals]
            for v in vals:
                if isinstance(v, (int, float)) and not (ch.limits[0] <= v <= ch.limits[1]):
                    raise SafetyLimitError(
                        f"write {self.name}.{channel}={v!r} rejected: outside envelope "
                        f"[{ch.limits[0]:g}, {ch.limits[1]:g}] {ch.unit}".rstrip())
        return ch.write_fn(value)

    def manifest(self) -> Dict:
        return {"name": self.name, "device_class": self.device_class, "description": self.description,
                "tags": self.tags, "channels": [c.spec() for c in self.channels.values()]}


class Registry:
    def __init__(self, devices: Optional[List[Device]] = None):
        self._d: Dict[str, Device] = {}
        self.listeners: List[Callable[[str, str, Any, Any], None]] = []  # (device, channel, value, result)
        for d in devices or []:
            self.add(d)

    def add(self, d: Device) -> None:
        if d.name in self._d:
            raise ValueError(f"duplicate device {d.name!r}")
        self._d[d.name] = d

    def get(self, name: str) -> Device:
        if name not in self._d:
            raise KeyError(f"no device {name!r} (attached: {sorted(self._d)})")
        return self._d[name]

    def names(self) -> List[str]:
        return sorted(self._d)

    def manifests(self) -> List[Dict]:
        return [self._d[n].manifest() for n in self.names()]

    def read(self, device: str, channel: str) -> Any:
        return self.get(device).read(channel)

    def write(self, device: str, channel: str, value: Any = None) -> Any:
        result = self.get(device).write(channel, value)
        for fn in self.listeners:
            fn(device, channel, value, result)
        return result
