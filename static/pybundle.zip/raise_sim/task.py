"""Task definition for the RAISE SDS 94 % + Tween 20 benchmark (T1).

Desirability reconstructed from Table 1 of the RAISE paper:
    D = sqrt( d_angle * d_total ),
    d_angle = 1 - |theta - 72| / 50      (triangular MATCH target on [22, 122] deg)
    d_total = 1 - total / 2.0            (linear MIN target on [0, 2] % w/v)
With these bounds 5 of the 6 Table 1 desirabilities reproduce to 2 decimals
(the sixth is off by 0.01). The 2.0 upper bound also matches the S4b colour bar.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List, Tuple


@dataclass(frozen=True)
class Task:
    name: str = "T1_raise_sds94_tween20"
    target_deg: float = 72.0
    angle_bounds: Tuple[float, float] = (22.0, 122.0)
    total_bounds: Tuple[float, float] = (0.0, 2.0)
    window: Tuple[float, float] = (70.39, 73.61)   # target +- 2 * 0.805
    sds_range: Tuple[float, float] = (0.04, 0.60)
    tween_range: Tuple[float, float] = (0.04, 1.20)
    step: float = 0.04
    optimal_desirability: float = 0.90

    def grid(self) -> List[Tuple[float, float]]:
        n_s = int(round((self.sds_range[1] - self.sds_range[0]) / self.step)) + 1
        n_t = int(round((self.tween_range[1] - self.tween_range[0]) / self.step)) + 1
        return [(round(self.sds_range[0] + i * self.step, 2), round(self.tween_range[0] + j * self.step, 2))
                for i in range(n_s) for j in range(n_t)]

    def d_angle(self, theta: float) -> float:
        half = (self.angle_bounds[1] - self.angle_bounds[0]) / 2
        return max(0.0, 1 - abs(theta - self.target_deg) / half)

    def d_total(self, total: float) -> float:
        lo, hi = self.total_bounds
        return max(0.0, min(1.0, (hi - total) / (hi - lo)))

    def desirability(self, theta: float, sds: float, tween: float) -> float:
        return math.sqrt(self.d_angle(theta) * self.d_total(sds + tween))

    def is_optimal(self, theta: float, sds: float, tween: float) -> bool:
        return (self.window[0] <= theta <= self.window[1]
                and self.desirability(theta, sds, tween) >= self.optimal_desirability)


T1 = Task()
