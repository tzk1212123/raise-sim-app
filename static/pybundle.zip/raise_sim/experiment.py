"""Experiment API: one call = one formulation = one JSON record.

    exp = create_experiment(surface="physics", seed=0)
    rec = exp.run(sds=0.08, tween=0.20)
    # -> {"run_id": 1, "status": "ok", "contact_angle_mean": 72.4, "contact_angle_sd": 0.6,
    #     "n_valid": 3, "droplets": [...], "set": {...}, "actual_wv_pct": {...}, ...}

Planners and agents only ever see these public records. Ground truth (true angle,
outlier flags) is kept in `exp.truth_log` for evaluation and is never returned.
Failed measurements come back as `contact_angle_mean: None` with a status; they
must be treated as missing data, never as a number.
"""
from __future__ import annotations

import itertools
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Dict, List, Optional

from .config import SimConfig
from .lab import InfeasibleFormulation, Protocol, SimLab, build_devices
from .mhs import DeviceError, SafetyLimitError
from .task import T1, Task


class Experiment:
    def __init__(self, surface: Callable[[float, float], float], cfg: Optional[SimConfig] = None,
                 task: Task = T1):
        self.cfg = cfg or SimConfig()
        self.task = task
        self.lab = SimLab(surface, self.cfg)
        self.registry = build_devices(self.lab)
        self.protocol = Protocol(self.lab, self.registry)
        self._ids = itertools.count(1)
        self.history: List[Dict] = []
        self.truth_log: List[Dict] = []
        self.listeners: List[Callable[[str], None]] = []
        self._log_path = None
        if self.cfg.data_dir:
            d = Path(self.cfg.data_dir)
            d.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            self._log_path = d / f"runs_{stamp}.jsonl"
            self._truth_path = d / f"truth_{stamp}.jsonl"

    # -- validation ------------------------------------------------------
    def validate(self, sds: float, tween: float) -> Optional[str]:
        c = self.cfg
        for name, v, (lo, hi) in (("sds", sds, c.sds_bounds), ("tween", tween, c.tween_bounds)):
            if not isinstance(v, (int, float)):
                return f"{name} must be a number"
            if not (lo - 1e-9 <= v <= hi + 1e-9):
                return f"{name}={v:g} outside allowed range [{lo:g}, {hi:g}] % w/v"
            if c.grid_step:
                k = round((v - lo) / c.grid_step)
                if abs(lo + k * c.grid_step - v) > 1e-6:
                    return f"{name}={v:g} not on the {c.grid_step:g} % grid starting at {lo:g}"
        return None

    def emit(self, msg: str) -> None:
        for fn in self.listeners:
            fn(msg)

    # -- the run ---------------------------------------------------------
    def run(self, sds: float, tween: float, tag: str = "") -> Dict:
        run_id = next(self._ids)
        sds, tween = round(float(sds), 4), round(float(tween), 4)
        base = {"run_id": run_id, "set": {"sds_wv_pct": sds, "tween_wv_pct": tween}, "tag": tag}
        err = self.validate(sds, tween)
        clock0, resets0 = self.lab.clock_s, self.lab.manual_resets
        truth = None
        if err:
            rec = {**base, "status": "rejected", "error": err, "contact_angle_mean": None, "n_valid": 0}
        else:
            try:
                out = self.protocol.run(sds, tween)
                truth = out.pop("_truth")
                rec = {**base, **out}
            except InfeasibleFormulation as e:
                rec = {**base, "status": "infeasible", "error": str(e), "contact_angle_mean": None, "n_valid": 0}
            except (DeviceError, SafetyLimitError) as e:
                rec = {**base, "status": "device_error", "error": str(e), "contact_angle_mean": None, "n_valid": 0}
        rec["total_wv_pct"] = round(sds + tween, 4)
        if rec.get("contact_angle_mean") is not None:
            rec["desirability"] = round(self.task.desirability(rec["contact_angle_mean"], sds, tween), 4)
        else:
            rec["desirability"] = None
        rec["sim_clock_s"] = round(self.lab.clock_s, 1)
        rec["manual_resets_during_run"] = self.lab.manual_resets - resets0
        rec.pop("steps", None)
        self.history.append(rec)
        t = {"run_id": run_id, "set": rec["set"], "tag": tag, "status": rec["status"],
             "theta_true_at_set": round(float(self.lab.surface(sds, tween)), 3) if not err else None,
             **({"theta_true_at_actual": truth["theta_true_at_actual"], "droplets": truth["droplets"]} if truth else {})}
        self.truth_log.append(t)
        if self._log_path:
            with self._log_path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(rec) + "\n")
            with self._truth_path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(t) + "\n")
        self.emit(f"run {run_id} {tag}: SDS={sds:g} Tween={tween:g} -> {rec['status']} "
                  f"angle={rec.get('contact_angle_mean')} D={rec['desirability']}")
        return rec

    def status(self) -> Dict:
        lab = self.lab
        return {"runs": len(self.history), "sim_clock_min": round(lab.clock_s / 60, 1),
                "manual_resets": lab.manual_resets, "human_time_min": round(lab.human_time_s / 60, 1),
                "free_spots": self.registry.read("deck", "free_spots"),
                "tips_left": {"p20": lab.tips["p20"], "p300": lab.tips["p300"]},
                "stocks_uL": self.registry.read("deck", "stocks_uL")}

    def task_description(self) -> Dict:
        t, c = self.task, self.cfg
        return {"name": t.name, "target_contact_angle_deg": t.target_deg,
                "acceptable_window_deg": list(t.window),
                "objective": "match the target static contact angle while minimising total surfactant",
                "desirability": "sqrt((1-|angle-72|/50) * (1-total/2.0))",
                "inputs": {"sds_wv_pct": list(c.sds_bounds), "tween_wv_pct": list(c.tween_bounds),
                           "grid_step": c.grid_step},
                "measurement": f"{c.droplets} droplets of {c.droplet_volume_uL:g} uL; mean and SD reported; "
                               "failed detections are returned as missing values"}


def make_surface(kind: str = "physics", index: int = 0):
    """Ground-truth surfaces: 'physics' (model A fit), 'family' (posterior draw `index`),
    'gp' (model B emulator)."""
    if kind == "physics":
        from .outcome.validate import load
        return load()
    if kind == "family":
        from .outcome.family import sample_family
        return sample_family(index + 1, seed=12345)[index]
    if kind == "gp":
        from .outcome.emulator import GPEmulator
        return GPEmulator()
    raise ValueError(f"unknown surface kind {kind!r}")


def create_experiment(surface: str = "physics", surface_index: int = 0, seed: Optional[int] = None,
                      **cfg_overrides) -> Experiment:
    cfg = SimConfig(seed=seed, **cfg_overrides)
    return Experiment(make_surface(surface, surface_index), cfg)
